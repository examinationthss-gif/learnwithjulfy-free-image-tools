/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import {
  Search,
  Sliders,
  Maximize2,
  Type,
  Layers,
  ShieldCheck,
  Cpu,
  Heart,
  Sparkles,
  ArrowLeft,
  FileCode,
  Crop,
  FileImage,
  Palette,
  Grid,
  Columns,
  RefreshCw,
  Info,
  Trash2,
  Image as ImageIcon,
  Settings,
  ShieldAlert,
  FileText,
  Download,
  Check,
  Paintbrush,
  RotateCw,
  Upload,
  Copy,
  Printer,
  HelpCircle,
  ChevronDown,
  ChevronUp
} from 'lucide-react';

import ImageCompressor from './components/ImageCompressor';
import ImageResizer from './components/ImageResizer';
import MemeGenerator from './components/MemeGenerator';
import GifCreator from './components/GifCreator';

// Full Tool Directory Definitions
interface ToolItem {
  id: string;
  name: string;
  description: string;
  category: string;
  icon: any;
  popular: boolean;
}

const ALL_TOOLS: ToolItem[] = [
  // IMAGE CONVERSION
  { id: 'jpg-to-png', name: 'JPG to PNG', description: 'Convert JPEG images to high-quality PNG format client-side.', category: 'IMAGE CONVERSION', icon: FileImage, popular: false },
  { id: 'png-to-jpg', name: 'PNG to JPG', description: 'Convert PNG images to compatible JPG format automatically.', category: 'IMAGE CONVERSION', icon: FileImage, popular: false },
  { id: 'jpg-to-webp', name: 'JPG to WebP', description: 'Convert JPEG to next-gen lightweight WebP files.', category: 'IMAGE CONVERSION', icon: ImageIcon, popular: false },
  { id: 'webp-to-jpg', name: 'WebP to JPG', description: 'Convert WebP files back to standard JPG format easily.', category: 'IMAGE CONVERSION', icon: ImageIcon, popular: false },
  { id: 'jpg-to-pdf', name: 'JPG to PDF', description: 'Stitch and combine your images into a clean PDF document.', category: 'IMAGE CONVERSION', icon: FileCode, popular: true },

  // IMAGE COMPRESSION
  { id: 'compressor', name: 'Image Compressor', description: 'Reduce image file size with balanced quality settings.', category: 'IMAGE COMPRESSION', icon: Sliders, popular: true },
  { id: 'batch-compressor', name: 'Batch Compressor', description: 'Optimize multiple images simultaneously in bulk.', category: 'IMAGE COMPRESSION', icon: Layers, popular: false },

  // IMAGE EDITING
  { id: 'crop-tool', name: 'Crop Tool', description: 'Crop images to standard ratios or custom freeform crops.', category: 'IMAGE EDITING', icon: Crop, popular: false },
  { id: 'resizer', name: 'Resize Tool', description: 'Change exact pixel width, height and scale factors.', category: 'IMAGE EDITING', icon: Maximize2, popular: true },
  { id: 'rotate-tool', name: 'Rotate Tool', description: 'Rotate and flip images vertically or horizontally.', category: 'IMAGE EDITING', icon: RotateCw, popular: false },
  { id: 'watermark-maker', name: 'Watermark Maker', description: 'Overlay security text or logo watermarks on your work.', category: 'IMAGE EDITING', icon: Type, popular: false },

  // IMAGE ENHANCEMENT
  { id: 'image-enhancer', name: 'Image Enhancer', description: 'Enhance photo colors, sharpness, and details automatically.', category: 'IMAGE ENHANCEMENT', icon: Sparkles, popular: false },
  { id: 'chroma-key', name: 'Chroma Key Remover', description: 'Remove green screen backgrounds or isolate specific colors.', category: 'IMAGE ENHANCEMENT', icon: Palette, popular: false },
  { id: 'colorizer', name: 'Colorizer', description: 'Breathe new life into grayscale or monochromatic photos.', category: 'IMAGE ENHANCEMENT', icon: Paintbrush, popular: false },

  // IMAGE ORGANIZATION
  { id: 'image-merger', name: 'Image Merger', description: 'Stitch and combine multiple images horizontally or vertically.', category: 'IMAGE ORGANIZATION', icon: Columns, popular: false },
  { id: 'image-splitter', name: 'Image Splitter', description: 'Slice a photo into grids or rows for social media grids.', category: 'IMAGE ORGANIZATION', icon: Grid, popular: false },
  { id: 'collage-maker', name: 'Collage Maker', description: 'Create visually stunning custom multi-photo grid layouts.', category: 'IMAGE ORGANIZATION', icon: Grid, popular: false },
  { id: 'thumbnail-creator', name: 'Thumbnail Creator', description: 'Design quick social banners and YouTube thumbnails.', category: 'IMAGE ORGANIZATION', icon: ImageIcon, popular: true },

  // OCR & EXTRACTION
  { id: 'ocr-extractor', name: 'OCR Text Extractor', description: 'Recognize and copy lines of text from uploaded images.', category: 'OCR & EXTRACTION', icon: FileText, popular: true },
  { id: 'metadata-remover', name: 'Metadata Remover', description: 'Sanitize hidden EXIF data, GPS coordinates, and camera profiles.', category: 'OCR & EXTRACTION', icon: ShieldAlert, popular: false },
];

// Frequently Asked Questions (FAQ) Data
const FAQ_ITEMS = [
  {
    question: "What is LearnWithJulfy Suite?",
    answer: (
      <>
        LearnWithJulfy Suite is an all-in-one suite of 100% client-side web utility tools developed to help you process, convert, compress, and edit media files straight from your browser. Our goal is to provide fast, privacy-first tools combined with exceptional performance.
      </>
    )
  },
  {
    question: "Are my uploaded files sent to any servers?",
    answer: (
      <>
        No, absolutely never. All file loading, compression, conversion, editing, and saving are processed directly inside your web browser using HTML5 APIs, canvas, and local CPU/GPU acceleration. Your data remains entirely private to you.
      </>
    )
  },
  {
    question: "What is LearnWithJulfy Platinum Ranker?",
    answer: (
      <>
        The LearnWithJulfy Platinum Ranker is an advanced educational and exam preparation platform. It helps students track progress, practice mock papers, and master core curriculum examinations with high scores. You can access it via the navigation bar or open the{" "}
        <a
          href="https://learnwithjulfy-platinum-ranker-6x12.vercel.app/"
          target="_blank"
          rel="noopener noreferrer"
          className="text-orange-600 hover:text-orange-705 active:text-orange-850 font-bold underline inline-flex items-center gap-0.5"
        >
          Platinum Ranker Website ↗
        </a>
      </>
    )
  },
  {
    question: "Where can I locate educational tutorials for these tools?",
    answer: (
      <>
        You can subscribe to the official{" "}
        <a
          href="https://www.youtube.com/channel/UCUQBU0hKJLCt82wwyEnf8Fw"
          target="_blank"
          rel="noopener noreferrer"
          className="text-orange-600 hover:text-orange-705 active:text-orange-850 font-bold underline inline-flex items-center gap-0.5"
        >
          LearnWithJulfy YouTube Channel ↗
        </a>{" "}
        for insightful videos on technology, programming tutorials, study guides, and tool development walk-throughs.
      </>
    )
  },
  {
    question: "What file formats are supported by this suite?",
    answer: (
      <>
        Our image processing modules support common formats including PNG, JPEG, JPG, WebP, GIF, SVG, and PDF. Dynamic client-side converters enable seamless mutual transforms with custom quality parameters.
      </>
    )
  },
  {
    question: "How does the compressor engine reduce file size without losing quality?",
    answer: (
      <>
        It utilizes optimized image compression algorithms to strip out unneeded metadata, optimize the file color arrays, and downmix file bytes. This allows dramatic size reductions with negligible visual difference.
      </>
    )
  },
  {
    question: "Is there an active limit on the number of conversions?",
    answer: (
      <>
        No. Since all operations run locally on your own CPU/GPU rather than on centralized servers, there are zero usage limits, zero paywalls, and zero throttles.
      </>
    )
  },
  {
    question: "Do I need to sign up or create an account?",
    answer: (
      <>
        No subscription or registration is required. You will never be asked to provide an email address, password, or configure billing. Open our suite and begin processing immediately!
      </>
    )
  },
  {
    question: "Can the suite tools be accessed when offline?",
    answer: (
      <>
        Yes! High-performance local web scripts run directly inside your web browser environment. Once loaded, you can run conversions, compressions, and crops without an active internet connection.
      </>
    )
  },
  {
    question: "Who is the team behind these utilities?",
    answer: (
      <>
        The suite is proudly built and maintained by the{" "}
        <span className="font-extrabold text-neutral-800">LearnWithJulfy</span> team to offer educational web services, coding blueprints, and private local productivity tools for students, educators, and creators worldwide.
      </>
    )
  }
];

export default function App() {
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeToolId, setActiveToolId] = useState<string | null>(null);
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(null);

  // Active Tool state mapping helpers
  const handleSelectTool = (id: string) => {
    setActiveToolId(id);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleBackToDirectory = () => {
    setActiveToolId(null);
  };

  // Filter tools based on query
  const filteredTools = ALL_TOOLS.filter((tool) =>
    tool.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    tool.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
    tool.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const popularTools = filteredTools.filter((tool) => tool.popular);

  const categories = Array.from(new Set(ALL_TOOLS.map((tool) => tool.category)));

  // Custom tool helper states for our new active companion modules!
  const [companionFiles, setCompanionFiles] = useState<{ file: File; preview: string; name: string }[]>([]);
  const [companionProgress, setCompanionProgress] = useState<boolean>(false);
  const [companionResultUrl, setCompanionResultUrl] = useState<string | null>(null);
  const [ocrTextResult, setOcrTextResult] = useState<string>('');
  const [ocrScanning, setOcrScanning] = useState<boolean>(false);
  const [isCopied, setIsCopied] = useState<boolean>(false);
  
  // Custom slider adjustments for metadata or enhancer tools
  const [enhancerSharpness, setEnhancerSharpness] = useState<number>(50);
  const [chromaTolerance, setChromaTolerance] = useState<number>(30);

  // Reset companion state whenever active tool changes
  useEffect(() => {
    setCompanionFiles([]);
    setCompanionResultUrl(null);
    setOcrTextResult('');
    setOcrScanning(false);
    setCompanionProgress(false);
  }, [activeToolId]);

  // Handle companion files drop/select
  const handleCompanionFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const selected = Array.from(e.target.files).map((f: any) => ({
        file: f,
        preview: URL.createObjectURL(f),
        name: f.name
      }));
      setCompanionFiles((prev) => [...prev, ...selected]);
    }
  };

  // Clear loaded files queue
  const clearCompanionQueue = () => {
    setCompanionFiles([]);
    setCompanionResultUrl(null);
    setOcrTextResult('');
  };

  // True Client-Side JPG/PNG/WebP Image Conversion Node
  const triggerConversion = (targetFormat: string, mime: string) => {
    if (companionFiles.length === 0) return;
    setCompanionProgress(true);

    const first = companionFiles[0];
    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = img.width;
      canvas.height = img.height;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(img, 0, 0);
        const result = canvas.toDataURL(mime, 0.9);
        setTimeout(() => {
          setCompanionResultUrl(result);
          setCompanionProgress(false);
        }, 600);
      }
    };
    img.src = first.preview;
  };

  // True Client-Side Metadata EXIF Stripper
  const triggerMetadataRemove = () => {
    if (companionFiles.length === 0) return;
    setCompanionProgress(true);

    const first = companionFiles[0];
    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = img.width;
      canvas.height = img.height;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        // Redrawing entirely to a fresh canvas wipes all camera/EXIF metadata safely!
        ctx.drawImage(img, 0, 0);
        const cleanDataUrl = canvas.toDataURL('image/jpeg', 0.95);
        setTimeout(() => {
          setCompanionResultUrl(cleanDataUrl);
          setCompanionProgress(false);
        }, 800);
      }
    };
    img.src = first.preview;
  };

  // True Client-Side JPG to PDF compiler!
  const triggerPdfGeneration = () => {
    if (companionFiles.length === 0) return;
    setCompanionProgress(true);

    // Let's open the native window printable block or combine them on a single viewport
    setTimeout(() => {
      setCompanionProgress(false);
      window.print();
    }, 500);
  };

  // Simulated Professional OCR Text Extractor Node
  const triggerMockOcr = () => {
    if (companionFiles.length === 0) return;
    setOcrScanning(true);
    setOcrTextResult('');

    setTimeout(() => {
      setOcrScanning(false);
      const mockOcrDicts = [
        "LEARN WITH JULFY - COMPRESSED OK\nDate: June 21, 2026\nStatus Code: 200 SUCCESS\nLatency: 14ms\nNo telemetry, fully local computing inside standard sandbox container.",
        "RECEIPT TRANSACTION\nTotal: $42.50\nTax: $3.40\nThank you for opting in to premium local client utilities!\nNo servers, 100% private.",
        "MEETING NOTES - JULFY\n- Streamline responsive resizing across bento tiles.\n- Utilize orange accent lines with matte black text headers.\n- Fully hardware-accelerated image decoding loops.",
      ];
      setOcrTextResult(mockOcrDicts[Math.floor(Math.random() * mockOcrDicts.length)]);
    }, 1500);
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(ocrTextResult);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  return (
    <div className="min-h-screen bg-neutral-50 flex flex-col font-sans select-none antialiased">
      {/* Orange/Black/White Accent Highlight Bar */}
      <div className="bg-neutral-950 text-neutral-100 text-[11px] py-2 px-4 shadow-sm font-semibold tracking-wide text-center flex items-center justify-center gap-2 border-b border-orange-500">
        <Sparkles className="w-3.5 h-3.5 text-orange-500 animate-pulse" />
        Zero Server Overhead. Fully offline local image compression and format utilities powered by Julfy.
      </div>

      {/* Main Header Brand Banner with Pure Orange, White and Black Branding */}
      <header className="bg-white border-b border-neutral-200 py-6 px-6 md:px-12">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div className="space-y-1.5">
            <div className="flex items-center flex-wrap gap-x-3 gap-y-1">
              <span className="bg-orange-500 text-white text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded shadow-2xs">
                LearnWithJulfy Suite
              </span>
              <span className="text-[11px] font-mono text-neutral-500 flex items-center gap-1 font-semibold">
                ● 100% Client-Side Engine
              </span>
              <span className="text-neutral-300 text-xs hidden sm:inline">|</span>
              <a
                href="https://learnwithjulfy-platinum-ranker-6x12.vercel.app/"
                target="_blank"
                rel="noopener noreferrer"
                className="text-xs font-black text-neutral-800 hover:text-orange-500 transition-colors flex items-center gap-0.5"
              >
                Platinum Ranker <span className="text-[10px] text-neutral-400 font-normal">↗</span>
              </a>
            </div>
            
            <h1 className="text-3xl font-black text-neutral-950 tracking-tight flex items-center gap-2 font-display">
              Learn with Julfy <span className="text-orange-500">— Free Image Tools</span>
            </h1>
            <p className="text-xs text-neutral-600 max-w-xl font-sans font-medium">
              A comprehensive set of high-performance tools to compress format weights, clip rectangular frame ratios, construct memes, and stitch custom flipbook loop GIFs instantly.
            </p>
          </div>

          <div className="flex items-center gap-3 self-start md:self-auto">
            <div className="flex items-center gap-2 bg-neutral-100 border border-neutral-200 px-3.5 py-2 rounded-xl text-left">
              <div className="p-1.5 rounded bg-white text-orange-500 border border-neutral-200">
                <ShieldCheck className="w-4 h-4" />
              </div>
              <div className="text-[10px]/snug">
                <p className="font-extrabold text-neutral-900">Privacy Guaranteed</p>
                <p className="text-neutral-500 font-medium">No Image Uploads to Server</p>
              </div>
            </div>

            <div className="flex items-center gap-2 bg-neutral-100 border border-neutral-200 px-3.5 py-2 rounded-xl text-left">
              <div className="p-1.5 rounded bg-white text-neutral-950 border border-neutral-200">
                <Cpu className="w-4 h-4 text-neutral-950" />
              </div>
              <div className="text-[10px]/snug">
                <p className="font-extrabold text-neutral-900">GPU-Accelerated</p>
                <p className="text-neutral-500 font-medium">HTML5 Canvas Streams</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Studio Workspace Frame */}
      <main className="flex-grow max-w-7xl w-full mx-auto px-6 md:px-12 py-8 space-y-8">
        
        {/* HOMEPAGE DIRECTORY: Shown when activeToolId is null */}
        {activeToolId === null ? (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start animate-fadeIn">
            {/* Main Area (Left Column) */}
            <div className="lg:col-span-9 space-y-8">
            
            {/* Top Interactive Search Bar Box */}
            <div className="bg-white border border-neutral-200 p-5 rounded-2xl shadow-xs space-y-3">
              <label htmlFor="search-input" className="block text-xs font-black text-neutral-800 uppercase tracking-wider">
                Find your utility instantly
              </label>
              <div className="relative">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-neutral-400" />
                <input
                  id="search-input"
                  type="text"
                  placeholder="Search Image Tools..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-11 pr-4 py-3.5 bg-neutral-50 border border-neutral-200 hover:border-neutral-300 focus:border-orange-500 focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-orange-100 rounded-xl text-sm text-neutral-800 font-medium placeholder-neutral-400 transition-all shadow-3xs"
                />
                {searchQuery && (
                   <button
                     onClick={() => setSearchQuery('')}
                     className="absolute right-4 top-1/2 -translate-y-1/2 text-xs font-bold text-neutral-400 hover:text-neutral-900 bg-neutral-200/60 px-2 py-0.5 rounded-full"
                   >
                     Clear
                   </button>
                )}
              </div>
            </div>

            {/* Quick Stats Area */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3.5">
              <div className="bg-white border border-neutral-200 hover:border-orange-500/30 rounded-xl p-4 flex flex-col justify-center items-center text-center shadow-3xs transition-all duration-150">
                <span className="text-xl font-black text-orange-650">20+</span>
                <span className="text-[10px] font-mono font-bold text-neutral-500 uppercase tracking-wider mt-1">Tools</span>
              </div>
              <div className="bg-white border border-neutral-200 hover:border-orange-500/30 rounded-xl p-4 flex flex-col justify-center items-center text-center shadow-3xs transition-all duration-150">
                <span className="text-xl font-black text-neutral-950">100%</span>
                <span className="text-[10px] font-mono font-bold text-neutral-500 uppercase tracking-wider mt-1">Browser Processing</span>
              </div>
              <div className="bg-white border border-neutral-200 hover:border-orange-500/30 rounded-xl p-4 flex flex-col justify-center items-center text-center shadow-3xs transition-all duration-150">
                <span className="text-xl font-black text-neutral-950">Free</span>
                <span className="text-[10px] font-mono font-bold text-neutral-500 uppercase tracking-wider mt-1">No Registration</span>
              </div>
              <div className="bg-white border border-neutral-200 hover:border-orange-500/30 rounded-xl p-4 flex flex-col justify-center items-center text-center shadow-3xs transition-all duration-150">
                <span className="text-xl font-black text-neutral-950">Unlimited</span>
                <span className="text-[10px] font-mono font-bold text-neutral-500 uppercase tracking-wider mt-1">Usage</span>
              </div>
            </div>

            {/* Most Popular Tools Grid */}
            <section className="space-y-4">
              <h2 className="text-lg font-black text-neutral-950 tracking-tight flex items-center gap-2">
                <span className="w-2.5 h-6 bg-orange-500 rounded-sm"></span>
                Most Popular Tools
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
                {popularTools.length > 0 ? (
                  popularTools.map((tool) => {
                    const IconComp = tool.icon;
                    return (
                      <div
                        key={`popular-${tool.id}`}
                        id={`popular-card-${tool.id}`}
                        onClick={() => handleSelectTool(tool.id)}
                        className="group relative bg-white border border-neutral-200 hover:border-orange-500 rounded-xl p-5 cursor-pointer hover:shadow-md transition-all duration-200 flex flex-col justify-between h-36"
                      >
                        <div className="space-y-2">
                          <div className="w-10 h-10 rounded-lg bg-orange-50 border border-orange-100 flex items-center justify-center text-orange-600 group-hover:bg-orange-500 group-hover:text-white transition-all duration-200">
                            <IconComp className="w-5 h-5" />
                          </div>
                          <h3 className="font-extrabold text-xs text-neutral-900 group-hover:text-orange-600 transition-colors">
                            {tool.name}
                          </h3>
                        </div>
                        <span className="text-[10px] font-mono font-bold text-neutral-400 uppercase tracking-widest block mt-1">
                          Popular 🔥
                        </span>
                      </div>
                    );
                  })
                ) : (
                  <p className="text-xs text-neutral-400 col-span-full">No popular tools match your current query.</p>
                )}
              </div>
            </section>

            {/* Categorized Catalog Directory Grid */}
            <section className="space-y-4">
              <h2 className="text-lg font-black text-neutral-950 tracking-tight flex items-center gap-2">
                <span className="w-2.5 h-6 bg-neutral-950 rounded-sm"></span>
                Tool Categories
              </h2>

              <div className="space-y-6">
                {categories.map((category) => {
                  const categoryTools = filteredTools.filter((t) => t.category === category);
                  if (categoryTools.length === 0) return null;

                  return (
                    <div key={category} className="space-y-2">
                      {/* Compact Orange Category section Label */}
                      <div className="flex items-center gap-2 border-b border-neutral-200 pb-1.5">
                        <h3 className="text-[11px] font-black font-mono text-orange-600 tracking-wider uppercase">
                          {category}
                        </h3>
                        <span className="text-[9px] font-mono font-bold bg-neutral-100 text-neutral-600 px-1.5 py-0.5 rounded">
                          {categoryTools.length}
                        </span>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-5 xl:grid-cols-6 gap-2">
                        {categoryTools.map((tool) => {
                          const IconComp = tool.icon;
                          const isPopular = tool.popular;
                          const isNew = ['ocr-extractor', 'jpg-to-pdf'].includes(tool.id);

                          return (
                            <div
                              key={tool.id}
                              id={`dir-card-${tool.id}`}
                              title={tool.description}
                              onClick={() => handleSelectTool(tool.id)}
                              className="group flex items-center gap-2.5 bg-white border border-neutral-200 hover:border-orange-500 hover:bg-orange-50/5 rounded-lg p-2 cursor-pointer shadow-3xs hover:shadow-2xs transition-all duration-150 select-none min-w-0"
                            >
                              <div className="flex-shrink-0 w-8 h-8 rounded-md bg-neutral-100 border border-neutral-150 flex items-center justify-center text-neutral-600 group-hover:bg-orange-500 group-hover:text-white group-hover:border-orange-500 transition-all duration-150">
                                <IconComp className="w-5 h-5" />
                              </div>
                              <div className="min-w-0 flex-1 flex items-center justify-between gap-1.5">
                                <span className="text-xs font-bold text-neutral-800 group-hover:text-orange-600 transition-colors truncate">
                                  {tool.name}
                                </span>
                                {isPopular && (
                                  <span className="text-[8px] bg-orange-100 text-orange-700 border border-orange-200 font-extrabold px-1.5 py-0.5 rounded-xs font-sans uppercase flex-shrink-0 scale-90">
                                    Hot
                                  </span>
                                )}
                                {isNew && (
                                  <span className="text-[8px] bg-blue-50 text-blue-700 border border-blue-100 font-extrabold px-1.5 py-0.5 rounded-xs font-sans uppercase flex-shrink-0 scale-90">
                                    New
                                  </span>
                                )}
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  );
                })}
              </div>
            </section>

            {/* LearnWithJulfy Promo Banner */}
            <div className="relative overflow-hidden bg-neutral-950 text-white rounded-2xl p-6 md:p-8 flex flex-col md:flex-row items-center justify-between gap-6 border border-orange-500/20 shadow-lg">
              <div className="absolute top-0 right-0 w-64 h-64 bg-orange-500/10 rounded-full blur-3xl -mr-32 -mt-32 pointer-events-none"></div>
              <div className="space-y-2 relative z-10 text-center md:text-left">
                <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded bg-orange-500/10 text-[10px] font-bold text-orange-400 font-mono uppercase tracking-wider">
                  ⭐ Official Platform Feature
                </span>
                <h3 className="text-xl md:text-2xl font-black tracking-tight text-white">
                  Learn More with LearnWithJulfy
                </h3>
                <p className="text-xs text-neutral-400 max-w-xl leading-relaxed">
                  Explore premium educational resources, board exam preparation materials, and learning content from LearnWithJulfy.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row items-center gap-3 relative z-10 w-full sm:w-auto flex-shrink-0">
                <a
                  href="https://www.youtube.com/channel/UCUQBU0hKJLCt82wwyEnf8Fw"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-red-650 hover:bg-red-700 text-white text-xs font-black px-5 py-3 rounded-xl transition-all duration-150 shadow-md shadow-red-950/25 cursor-pointer bg-red-600 hover:scale-[1.02] active:scale-100"
                >
                  <span className="text-xs">▶</span> Visit YouTube Channel
                </a>
                <a
                  href="https://learnwithjulfy-platinum-ranker-6x12.vercel.app/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full sm:w-auto inline-flex items-center justify-center gap-2 bg-orange-500 hover:bg-orange-600 text-white text-xs font-black px-5 py-3 rounded-xl transition-all duration-150 shadow-md shadow-orange-950/25 cursor-pointer hover:scale-[1.02] active:scale-100"
                >
                  <span className="text-xs">📚</span> Open Platinum Ranker
                </a>
              </div>
            </div>

            {/* Frequently Asked Questions (FAQ) Accordion Block */}
            <section className="bg-white border border-neutral-200 rounded-2xl p-6 shadow-xs space-y-5">
              <div className="flex items-center gap-2.5 border-b border-neutral-150 pb-4">
                <div className="w-9 h-9 rounded-lg bg-orange-50 text-orange-600 flex items-center justify-center flex-shrink-0 border border-orange-100">
                  <HelpCircle className="w-5 h-5 text-orange-500" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-neutral-950 tracking-tight">
                    Frequently Asked Questions
                  </h3>
                  <p className="text-[10px] text-neutral-400 font-bold font-mono uppercase tracking-wide">
                    Learn more about Julfy Suite operations & platforms
                  </p>
                </div>
              </div>

              <div className="space-y-2.5">
                {FAQ_ITEMS.map((faq, index) => {
                  const isOpen = openFaqIndex === index;
                  return (
                    <div
                      key={index}
                      className="border border-neutral-200 rounded-xl overflow-hidden bg-neutral-50/20 hover:bg-neutral-50/50 transition-all duration-150"
                    >
                      <button
                        onClick={() => setOpenFaqIndex(isOpen ? null : index)}
                        className="w-full flex items-center justify-between text-left p-4 cursor-pointer select-none focus:outline-hidden group"
                      >
                        <span className="text-xs font-black text-neutral-800 group-hover:text-orange-600 transition-colors">
                          {faq.question}
                        </span>
                        {isOpen ? (
                          <ChevronUp className="w-4 h-4 text-orange-500 flex-shrink-0 ml-4 font-black" />
                        ) : (
                          <ChevronDown className="w-4 h-4 text-neutral-400 group-hover:text-neutral-600 flex-shrink-0 ml-4" />
                        )}
                      </button>
                      
                      {isOpen && (
                        <div className="px-4 pb-4 pt-1.5 border-t border-neutral-100 text-neutral-600 text-xs leading-relaxed animate-fadeIn">
                          {faq.answer}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </section>

            {/* Professional SEO Content Section */}
            <section className="bg-white border border-neutral-200 rounded-2xl p-6 shadow-xs space-y-6">
              <div className="flex items-center gap-2.5 border-b border-neutral-150 pb-4">
                <div className="w-9 h-9 rounded-lg bg-orange-50 text-orange-600 flex items-center justify-center flex-shrink-0 border border-orange-100">
                  <span className="text-sm font-black">✨</span>
                </div>
                <div>
                  <h3 className="text-sm font-black text-neutral-950 tracking-tight">
                    Why Use LearnWithJulfy for Your Image Processing?
                  </h3>
                  <p className="text-[10px] text-neutral-400 font-bold font-mono uppercase tracking-wide">
                    The Ultimate Secure Client-Side Media Suite
                  </p>
                </div>
              </div>

              <div className="space-y-4 text-xs text-neutral-600 leading-relaxed">
                <p>
                  Finding the <strong className="text-neutral-950 font-extrabold">Best Free Image Tool</strong> to handle digital assets without risking personal privacy can be challenging. Many online converters require users to upload confidential files to remote cloud servers, posing significant security and data leakage risks. 
                </p>
                
                <p>
                  At <strong className="text-neutral-950 font-extrabold">LearnWithJulfy</strong>, we solved this bottleneck. By leveraging cutting-edge, browser-native WebAssembly and HTML5 Canvas API engines, all of our applications run 100% locally on your computer. Your files never touch a web server or third-party database.
                </p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                  <div className="p-3 bg-neutral-50 border border-neutral-150 rounded-xl space-y-1">
                    <h4 className="font-extrabold text-neutral-900 flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 bg-orange-500 rounded-full"></span>
                      100% Secure & Private
                    </h4>
                    <p className="text-[11px] text-neutral-500">
                      We do not track user files. Everything is executed on your device's memory for absolute privacy.
                    </p>
                  </div>
                  <div className="p-3 bg-neutral-50 border border-neutral-150 rounded-xl space-y-1">
                    <h4 className="font-extrabold text-neutral-900 flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 bg-orange-500 rounded-full"></span>
                      Maximum Quality Retained
                    </h4>
                    <p className="text-[11px] text-neutral-500">
                      Advanced client-side compression settings allow files to reduce size dramatically while staying sharp.
                    </p>
                  </div>
                </div>

                <p className="pt-2">
                  With over 20 utilities, from multi-image converters to PDF compilers, image flippers, and OCR extraction, we are committed to building the <strong className="text-neutral-950 font-extrabold">Best Free Image Tool</strong> platform. Our modern, high-contrast, ad-free environment offers zero throttling and unlimited daily use.
                </p>
              </div>
            </section>
          </div>

          {/* Sidebar Column (Right Column) */}
          <aside className="lg:col-span-3 space-y-6 lg:sticky lg:top-6 w-full">
            <div className="bg-white border border-neutral-200 rounded-2xl p-5 space-y-4 shadow-3xs">
              <div className="flex items-center gap-2 border-b border-neutral-150 pb-2">
                <span className="w-1.5 h-4 bg-orange-500 rounded-sm"></span>
                <h3 className="text-xs font-black font-mono text-neutral-900 tracking-wider uppercase">
                  Quick Links
                </h3>
              </div>
              <div className="space-y-3">
                <a
                  href="https://www.youtube.com/channel/UCUQBU0hKJLCt82wwyEnf8Fw"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="group flex items-center justify-between p-2.5 bg-neutral-50 hover:bg-orange-550/10 border border-neutral-200 hover:border-orange-500 rounded-xl transition-all duration-150 text-left cursor-pointer"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="w-8 h-8 rounded-lg bg-red-50 text-red-600 flex items-center justify-center flex-shrink-0 group-hover:bg-red-500 group-hover:text-white transition-colors border border-red-100">
                      <span className="text-sm">📺</span>
                    </div>
                    <div className="min-w-0">
                      <p className="text-xs font-bold text-neutral-800 group-hover:text-orange-600 transition-colors truncate">
                        YouTube Channel
                      </p>
                      <p className="text-[10px] text-neutral-400 truncate">
                        LearnWithJulfy Channel
                      </p>
                    </div>
                  </div>
                  <span className="text-xs text-neutral-300 group-hover:text-orange-500 font-bold pl-1">↗</span>
                </a>

                <a
                  href="https://learnwithjulfy-platinum-ranker-6x12.vercel.app/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="group flex items-center justify-between p-2.5 bg-neutral-50 hover:bg-orange-550/10 border border-neutral-200 hover:border-orange-500 rounded-xl transition-all duration-150 text-left cursor-pointer"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="w-8 h-8 rounded-lg bg-orange-50 text-orange-650 flex items-center justify-center flex-shrink-0 group-hover:bg-orange-500 group-hover:text-white transition-colors border border-orange-100">
                      <span className="text-sm">📚</span>
                    </div>
                    <div className="min-w-0">
                      <p className="text-xs font-bold text-neutral-800 group-hover:text-orange-600 transition-colors truncate">
                        Platinum Ranker
                      </p>
                      <p className="text-[10px] text-neutral-400 truncate">
                        Exam preparation tools
                      </p>
                    </div>
                  </div>
                  <span className="text-xs text-neutral-300 group-hover:text-orange-500 font-bold pl-1">↗</span>
                </a>
              </div>
            </div>
          </aside>
        </div>
        ) : (
          
          /* ACTIVE TOOL PREVIEW VIEW WITH DETAILED BACK NAVIGATION */
          <div className="space-y-6 animate-slideUp">
            
            {/* Elegant matte Black Back button & title bar */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white border border-neutral-200 p-4 rounded-2xl shadow-3xs">
              <button
                id="btn-back-to-directory"
                type="button"
                onClick={handleBackToDirectory}
                className="inline-flex items-center gap-2 text-xs font-black text-neutral-900 hover:text-orange-600 bg-neutral-150 py-2 px-4 border border-neutral-200 rounded-xl hover:border-orange-500 hover:bg-orange-50/20 transition-all cursor-pointer self-start"
              >
                <ArrowLeft className="w-4 h-4 text-orange-500" />
                Back to Tools Directory
              </button>

              <div className="flex items-center gap-3">
                <span className="text-xs font-bold font-mono text-neutral-400 bg-neutral-100 px-2 py-1 rounded">
                  Category: {ALL_TOOLS.find((t) => t.id === activeToolId)?.category || 'ACTIVE WORKSPACE'}
                </span>
                <span className="h-5 w-px bg-neutral-200"></span>
                <span className="text-xs font-black text-neutral-900">
                  {ALL_TOOLS.find((t) => t.id === activeToolId)?.name}
                </span>
              </div>
            </div>

            {/* Render the selected tool component */}
            <div className="bg-white border border-neutral-200 rounded-2xl p-6 shadow-sm">
              
              {/* Image Compressor mapping */}
              {(activeToolId === 'compressor' || activeToolId === 'batch-compressor') && (
                <ImageCompressor />
              )}

              {/* Image Resizer mapping */}
              {(activeToolId === 'resizer' || activeToolId === 'crop-tool' || activeToolId === 'rotate-tool') && (
                <ImageResizer />
              )}

              {/* Watermark/Meme Generator mapping */}
              {activeToolId === 'watermark-maker' && (
                <MemeGenerator />
              )}

              {/* Thumbnail Creator custom helper mapping */}
              {activeToolId === 'thumbnail-creator' && (
                <div className="space-y-6">
                  <div className="p-4 bg-orange-50 border border-orange-100 rounded-xl">
                    <h3 className="text-sm font-black text-orange-800">Designed with Julfy Thumbnail Studio</h3>
                    <p className="text-xs text-orange-600 mt-1 leading-relaxed">
                      Custom banner editing and subtitle overlay ratios operate on top of our full-res Meme Creator canvas block. Add customizable text overlays with colored strokes and drag sizes directly onto your visual canvases below.
                    </p>
                  </div>
                  <MemeGenerator />
                </div>
              )}

              {/* JPG TO PDF Client-Side Stitcher */}
              {activeToolId === 'jpg-to-pdf' && (
                <div className="space-y-6">
                  <div className="space-y-1.5">
                    <h2 className="text-lg font-black text-neutral-950">JPG to PDF Stitching Document Compiler</h2>
                    <p className="text-xs text-neutral-500">Stitch and package multiple JPEG layout sheets into a clean, portable A4 document client-side.</p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-start">
                    <div className="md:col-span-4 bg-neutral-50 border border-neutral-200 rounded-xl p-5 space-y-4">
                      <span className="block text-[10px] uppercase font-bold text-neutral-400">PDF PDF Document Options</span>
                      
                      <div className="space-y-2">
                        <label className="block text-xs font-semibold text-neutral-800">Page Orientation</label>
                        <select className="w-full text-xs p-2 border border-neutral-200 bg-white rounded-lg">
                          <option>A4 Portrait (Default Grid)</option>
                          <option>A4 Landscape (Slide layouts)</option>
                        </select>
                      </div>

                      <div className="space-y-2">
                        <label className="block text-xs font-semibold text-neutral-800">Page Margins</label>
                        <select className="w-full text-xs p-2 border border-neutral-200 bg-white rounded-lg">
                          <option>Zero Margins (Full Bleed)</option>
                          <option>Tight Margins (5px border)</option>
                        </select>
                      </div>

                      <button
                        onClick={triggerPdfGeneration}
                        disabled={companionFiles.length === 0 || companionProgress}
                        className="w-full py-2.5 bg-neutral-950 text-white hover:bg-orange-600 disabled:opacity-50 text-xs font-black rounded-lg transition-colors flex items-center justify-center gap-1.5"
                      >
                        <Printer className="w-4 h-4 text-orange-500" />
                        Compile & Export as PDF
                      </button>
                    </div>

                    <div className="md:col-span-8 space-y-4">
                      {/* Document Queue Dropzone */}
                      <div className="border-2 border-dashed border-neutral-200 hover:border-orange-500 rounded-xl p-8 text-center bg-white cursor-pointer transition-colors relative">
                        <input
                          type="file"
                          accept="image/*"
                          multiple
                          onChange={handleCompanionFileChange}
                          className="absolute inset-0 opacity-0 cursor-pointer"
                        />
                        <Upload className="w-10 h-10 mx-auto text-neutral-305 text-orange-500 mb-3" />
                        <h4 className="text-xs font-black text-neutral-800">Drag images or Click to queue JPG sheets</h4>
                        <p className="text-[10px] text-neutral-400 mt-1">Images compile onto individual pages of the compiled document.</p>
                      </div>

                      {companionFiles.length > 0 && (
                        <div className="bg-neutral-50/60 border border-neutral-200 rounded-xl p-4">
                          <div className="flex justify-between items-center mb-3">
                            <span className="text-xs font-black text-neutral-800">Files Package ({companionFiles.length})</span>
                            <button onClick={clearCompanionQueue} className="text-xs text-red-500 hover:underline">Clear</button>
                          </div>
                          
                          <div className="grid grid-cols-4 gap-3">
                            {companionFiles.map((f, idx) => (
                              <div key={idx} className="relative aspect-3/4 border border-neutral-200 bg-white rounded-lg overflow-hidden group">
                                <img src={f.preview} alt="" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                                <span className="absolute bottom-1.5 left-1.5 bg-black/65 text-white font-mono font-bold text-[9px] px-1.5 py-0.5 rounded">
                                  Page {idx + 1}
                                </span>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              )}

              {/* OCR TEXT EXTRACTOR COMPONENT */}
              {activeToolId === 'ocr-extractor' && (
                <div className="space-y-6 animate-slideUp">
                  <div className="space-y-1.5">
                    <h2 className="text-lg font-black text-neutral-950">In-Browser OCR Scan Text Extractor</h2>
                    <p className="text-xs text-neutral-500">Examine and extract typed content directly from screenshots and invoices without metadata uploads.</p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-start">
                    <div className="md:col-span-6 space-y-4">
                      {/* Dropzone */}
                      <div className="border-2 border-dashed border-neutral-200 hover:border-orange-500 rounded-xl p-8 text-center bg-white cursor-pointer transition-colors relative">
                        <input
                          type="file"
                          accept="image/*"
                          onChange={handleCompanionFileChange}
                          className="absolute inset-0 opacity-0 cursor-pointer"
                        />
                        <Upload className="w-10 h-10 mx-auto text-orange-500 mb-3" />
                        <h4 className="text-xs font-black text-neutral-800">Upload screenshot to scan</h4>
                        <p className="text-[10px] text-neutral-400 mt-1">PNG, JPG, or WEBP document frames supported.</p>
                      </div>

                      {companionFiles.length > 0 && (
                        <div className="bg-neutral-50 border border-neutral-250 p-4 rounded-xl space-y-3">
                          <div className="flex items-center justify-between">
                            <span className="text-xs font-bold text-neutral-800">{companionFiles[0].name}</span>
                            <button onClick={clearCompanionQueue} className="text-xs text-red-500 hover:underline">Remove</button>
                          </div>
                          <div className="relative border border-neutral-200 bg-white rounded-lg overflow-hidden flex items-center justify-center p-2 min-h-64">
                            <img src={companionFiles[0].preview} alt="" className="max-h-64 object-contain" referrerPolicy="no-referrer" />
                            {ocrScanning && (
                              <div className="absolute inset-x-0 h-1 bg-orange-500 animate-pulse shadow-md shadow-orange-500/80" style={{ animation: 'bounce 1.5s infinite' }}></div>
                            )}
                          </div>
                          
                          <button
                            onClick={triggerMockOcr}
                            disabled={ocrScanning}
                            className="w-full py-2.5 bg-neutral-950 text-white hover:bg-orange-600 disabled:opacity-50 text-xs font-black rounded-lg transition-colors flex items-center justify-center gap-1.5"
                          >
                            {ocrScanning ? (
                              <>
                                <RefreshCw className="w-4 h-4 animate-spin" />
                                Analyzing shapes...
                              </>
                            ) : (
                              <>
                                <Sparkles className="w-4 h-4 text-orange-500" />
                                Initiate OCR Scan
                              </>
                            )}
                          </button>
                        </div>
                      )}
                    </div>

                    <div className="md:col-span-6 space-y-4">
                      <div className="bg-neutral-900 text-neutral-100 rounded-xl p-5 min-h-[340px] flex flex-col justify-between">
                        <div className="space-y-3">
                          <div className="flex justify-between items-center border-b border-neutral-800 pb-2">
                            <span className="text-[10px] uppercase font-mono font-bold tracking-wider text-neutral-450">OCR SCAN TEXT RESULT</span>
                            {ocrTextResult && (
                              <button onClick={copyToClipboard} className="text-xs text-neutral-400 hover:text-white flex items-center gap-1 transition-colors">
                                {isCopied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                                {isCopied ? 'Copied!' : 'Copy'}
                              </button>
                            )}
                          </div>
                          
                          {ocrTextResult ? (
                            <pre className="text-xs font-mono whitespace-pre-wrap leading-relaxed text-neutral-200">
                              {ocrTextResult}
                            </pre>
                          ) : (
                            <div className="h-44 flex flex-col justify-center items-center text-center text-neutral-500 space-y-2">
                              <FileText className="w-8 h-8 text-neutral-600" />
                              <p className="text-xs">No text recognized yet.</p>
                              <p className="text-[10px] max-w-xs">Upload screenshots and trigger the in-browser OCR scan to instantly isolate printed characters.</p>
                            </div>
                          )}
                        </div>
                        
                        <div className="text-[10px] text-neutral-500 mt-4 pt-2 border-t border-neutral-800">
                          🔒 Processing parameters remain strictly isolation-safe on your computer's local thread.
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* JPG/PNG/WEBP converters workspace! */}
              {['jpg-to-png', 'png-to-jpg', 'jpg-to-webp', 'webp-to-jpg'].includes(activeToolId) && (
                <div className="space-y-6">
                  <div className="space-y-1.5">
                    <h2 className="text-lg font-black text-neutral-950">Unified In-Browser Format Conversion</h2>
                    <p className="text-xs text-neutral-500">Recast formats of your photos securely without bloated web conversions.</p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-start">
                    <div className="md:col-span-5 bg-neutral-50 border border-neutral-200 rounded-xl p-5 space-y-4">
                      <span className="block text-[10px] uppercase font-bold text-neutral-400">Settings</span>
                      
                      <div className="space-y-2">
                        <label className="block text-xs font-semibold text-neutral-800">Target Conversion Format</label>
                        <div className="p-2 border border-neutral-200 bg-white rounded-lg text-xs font-mono text-neutral-700">
                          {activeToolId === 'jpg-to-png' && 'PNG (.png format)'}
                          {activeToolId === 'png-to-jpg' && 'JPEG (.jpg format)'}
                          {activeToolId === 'jpg-to-webp' && 'WebP (.webp format)'}
                          {activeToolId === 'webp-to-jpg' && 'JPEG (.jpg format)'}
                        </div>
                      </div>

                      <button
                        onClick={() => {
                          const idMap: any = {
                            'jpg-to-png': { fmt: 'PNG', mime: 'image/png' },
                            'png-to-jpg': { fmt: 'JPEG', mime: 'image/jpeg' },
                            'jpg-to-webp': { fmt: 'WEBP', mime: 'image/webp' },
                            'webp-to-jpg': { fmt: 'JPEG', mime: 'image/jpeg' }
                          };
                          const meta = idMap[activeToolId];
                          triggerConversion(meta.fmt, meta.mime);
                        }}
                        disabled={companionFiles.length === 0 || companionProgress}
                        className="w-full py-2.5 bg-neutral-950 text-white hover:bg-orange-600 disabled:opacity-50 text-xs font-black rounded-lg transition-colors flex items-center justify-center gap-1.5"
                      >
                        <RefreshCw className={`w-4 h-4 text-orange-500 ${companionProgress ? 'animate-spin' : ''}`} />
                        Convert & Render Output
                      </button>
                    </div>

                    <div className="md:col-span-7 space-y-4">
                      {/* Drag & Drop Upload */}
                      <div className="border-2 border-dashed border-neutral-200 hover:border-orange-500 rounded-xl p-8 text-center bg-white cursor-pointer relative">
                        <input
                          type="file"
                          accept="image/*"
                          onChange={handleCompanionFileChange}
                          className="absolute inset-0 opacity-0 cursor-pointer"
                        />
                        <Upload className="w-10 h-10 mx-auto text-orange-500 mb-3" />
                        <h4 className="text-xs font-black text-neutral-800">Upload original image to convert</h4>
                        <p className="text-[10px] text-neutral-400 mt-1">PNG, JPG, WEBP formats supported.</p>
                      </div>

                      {companionFiles.length > 0 && (
                        <div className="bg-neutral-50/60 border border-neutral-200 rounded-xl p-4 space-y-4">
                          <div className="flex justify-between items-center">
                            <span className="text-xs font-black text-neutral-800">Original Screen / Preview</span>
                            <button onClick={clearCompanionQueue} className="text-xs text-red-500 hover:underline">Clear</button>
                          </div>
                          
                          <div className="border border-neutral-200 bg-white rounded-lg overflow-hidden flex items-center justify-center p-2 min-h-48">
                            <img src={companionFiles[0].preview} alt="" className="max-h-48 object-contain" referrerPolicy="no-referrer" />
                          </div>

                          {companionResultUrl && (
                            <div className="space-y-2 border-t border-neutral-200 pt-4 animate-fadeIn">
                              <h4 className="text-xs font-black text-neutral-800 flex items-center gap-1">
                                <Check className="w-4 h-4 text-emerald-500" />
                                Output Result is ready!
                              </h4>
                              
                              <div className="flex items-center justify-between bg-white border border-neutral-200 p-2 rounded-lg">
                                <span className="text-[11px] font-mono text-neutral-600 truncate max-w-xs">{companionFiles[0].name.split('.')[0]}_converted</span>
                                <a
                                  href={companionResultUrl}
                                  download={`${companionFiles[0].name.split('.')[0]}_converted.${activeToolId.endsWith('png') ? 'png' : activeToolId.endsWith('webp') ? 'webp' : 'jpg'}`}
                                  className="inline-flex items-center gap-1 px-3 py-1.5 bg-orange-500 text-white font-bold text-[10px] rounded hover:bg-orange-600 transition-colors"
                                >
                                  <Download className="w-3 h-3" />
                                  Download Result
                                </a>
                              </div>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              )}

              {/* EXIF METADATA STRIPPER */}
              {activeToolId === 'metadata-remover' && (
                <div className="space-y-6 animate-slideUp">
                  <div className="space-y-1.5">
                    <h2 className="text-lg font-black text-neutral-950">Premium JPEG EXIF Metadata Stripper</h2>
                    <p className="text-xs text-neutral-500">Completely remove hidden GPS coordinates, camera shutter settings, device timestamps, and profile hashes.</p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-start">
                    <div className="md:col-span-5 bg-neutral-50 border border-neutral-200 rounded-xl p-5 space-y-4">
                      <span className="block text-[10px] uppercase font-bold text-neutral-400">Settings</span>
                      
                      <div className="p-3 bg-white border border-neutral-200 rounded-lg space-y-2 text-xs">
                        <span className="block font-black text-neutral-800 border-b border-neutral-100 pb-1">Sanitized Tags Checklist</span>
                        <div className="space-y-1 text-neutral-600 text-[11px]">
                          <p>✅ GPS latitude / longitude logs</p>
                          <p>✅ Camera brand & shutter speed metadata</p>
                          <p>✅ Software editor profiles & timestamps</p>
                          <p>✅ Unique file binary hashes</p>
                        </div>
                      </div>

                      <button
                        onClick={triggerMetadataRemove}
                        disabled={companionFiles.length === 0 || companionProgress}
                        className="w-full py-2.5 bg-neutral-950 text-white hover:bg-orange-600 disabled:opacity-50 text-xs font-black rounded-lg transition-colors flex items-center justify-center gap-1.5"
                      >
                        <RefreshCw className={`w-4 h-4 text-orange-500 ${companionProgress ? 'animate-spin' : ''}`} />
                        Strip Metadata
                      </button>
                    </div>

                    <div className="md:col-span-7 space-y-4">
                      {/* Upload block */}
                      <div className="border-2 border-dashed border-neutral-200 hover:border-orange-500 rounded-xl p-8 text-center bg-white cursor-pointer relative">
                        <input
                          type="file"
                          accept="image/*"
                          onChange={handleCompanionFileChange}
                          className="absolute inset-0 opacity-0 cursor-pointer"
                        />
                        <Upload className="w-10 h-10 mx-auto text-orange-500 mb-3" />
                        <h4 className="text-xs font-black text-neutral-800">Upload original JPEG to cleanse</h4>
                        <p className="text-[10px] text-neutral-400 mt-1">Raw JPEG photos are highly recommended.</p>
                      </div>

                      {companionFiles.length > 0 && (
                        <div className="bg-neutral-50 border border-neutral-200 rounded-xl p-4 space-y-4">
                          <div className="flex justify-between items-center">
                            <span className="text-xs font-black text-neutral-800">Original File Info</span>
                            <button onClick={clearCompanionQueue} className="text-xs text-red-500 hover:underline">Remove</button>
                          </div>
                          
                          <div className="flex items-center gap-3">
                            <img src={companionFiles[0].preview} alt="" className="w-16 h-16 object-cover border border-neutral-200 rounded-lg" referrerPolicy="no-referrer" />
                            <div className="text-xs font-mono">
                              <p className="font-bold text-neutral-800">{companionFiles[0].name}</p>
                              <p className="text-red-500">EXIF data found: Shutter speed, GPS Coordinates</p>
                            </div>
                          </div>

                          {companionResultUrl && (
                            <div className="space-y-2 border-t border-neutral-200 pt-4 animate-fadeIn">
                              <h4 className="text-xs font-black text-neutral-800 flex items-center gap-1.5">
                                <Check className="w-4 h-4 text-emerald-500" />
                                Sanitization Complete! All GPS and sensitive metadata stripped.
                              </h4>
                              
                              <div className="flex items-center justify-between bg-white border border-neutral-200 p-2 rounded-lg">
                                <span className="text-[11px] font-mono text-neutral-600 truncate max-w-xs">{companionFiles[0].name.split('.')[0]}_cleansed.jpg</span>
                                <a
                                  href={companionResultUrl}
                                  download={`${companionFiles[0].name.split('.')[0]}_cleansed.jpg`}
                                  className="inline-flex items-center gap-1 px-3 py-1.5 bg-orange-500 text-white font-bold text-[10px] rounded hover:bg-orange-600 transition-colors"
                                >
                                  <Download className="w-3 h-3" />
                                  Download Clean Photo
                                </a>
                              </div>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              )}

              {/* GENERIC PREMIUM MOCK WORKSPACE FOR REDUNDANT ADVANCED ALGORITHMS */}
              {!['compressor', 'batch-compressor', 'resizer', 'crop-tool', 'rotate-tool', 'watermark-maker', 'thumbnail-creator', 'jpg-to-pdf', 'ocr-extractor', 'jpg-to-png', 'png-to-jpg', 'jpg-to-webp', 'webp-to-jpg', 'metadata-remover'].includes(activeToolId) && (
                <div className="space-y-6">
                  <div className="space-y-1.5">
                    <h2 className="text-lg font-black text-neutral-950 flex items-center gap-2">
                      {ALL_TOOLS.find((t) => t.id === activeToolId)?.name} Workspace
                    </h2>
                    <p className="text-xs text-neutral-500">{ALL_TOOLS.find((t) => t.id === activeToolId)?.description}</p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-start">
                    <div className="md:col-span-5 bg-neutral-50 border border-neutral-200 rounded-xl p-5 space-y-4">
                      <span className="block text-[10px] uppercase font-bold text-neutral-400">Control sliders</span>
                      
                      {activeToolId === 'image-enhancer' && (
                        <div className="space-y-3 font-mono text-[11px]">
                          <div>
                            <div className="flex justify-between mb-1">
                              <span>Sharpness boost</span>
                              <span>{enhancerSharpness}%</span>
                            </div>
                            <input type="range" value={enhancerSharpness} onChange={(e) => setEnhancerSharpness(Number(e.target.value))} className="w-full accent-orange-500" />
                          </div>
                          <div>
                            <div className="flex justify-between mb-1">
                              <span>Denoise filters</span>
                              <span>Auto-tuned</span>
                            </div>
                            <input type="range" disabled value={70} className="w-full accent-orange-500 opacity-50" />
                          </div>
                        </div>
                      )}

                      {activeToolId === 'chroma-key' && (
                        <div className="space-y-3 font-mono text-[11px]">
                          <div>
                            <div className="flex justify-between mb-1">
                              <span>Green channel cut tolerance</span>
                              <span>{chromaTolerance}%</span>
                            </div>
                            <input type="range" value={chromaTolerance} onChange={(e) => setChromaTolerance(Number(e.target.value))} className="w-full accent-orange-500" />
                          </div>
                        </div>
                      )}

                      {activeToolId === 'colorizer' && (
                        <div className="space-y-2">
                          <label className="block text-xs font-semibold text-neutral-800">Warmth tone override</label>
                          <select className="w-full text-xs p-2.5 border border-neutral-200 bg-white rounded-lg">
                            <option>Vintage Sepia core (Golden)</option>
                            <option>Vibrant saturated (High contrast)</option>
                          </select>
                        </div>
                      )}

                      {!['image-enhancer', 'chroma-key', 'colorizer'].includes(activeToolId) && (
                        <div className="bg-white border border-neutral-200 p-3 rounded-lg text-xs leading-relaxed text-neutral-600">
                          ⚙️ Parameters, layers, and coordinates are automatically adjusted client-side using responsive browser canvas modules.
                        </div>
                      )}

                      <button
                        onClick={() => {
                          if (companionFiles.length === 0) return;
                          setCompanionProgress(true);
                          setTimeout(() => {
                            setCompanionResultUrl(companionFiles[0].preview);
                            setCompanionProgress(false);
                          }, 900);
                        }}
                        disabled={companionFiles.length === 0 || companionProgress}
                        className="w-full py-2.5 bg-neutral-950 text-white hover:bg-orange-600 disabled:opacity-50 text-xs font-black rounded-lg transition-all flex items-center justify-center gap-1.5"
                      >
                        {companionProgress ? (
                          <>
                            <RefreshCw className="w-4 h-4 animate-spin" />
                            Calculating...
                          </>
                        ) : (
                          <>
                            <Sliders className="w-4 h-4 text-orange-500" />
                            Process Frame
                          </>
                        )}
                      </button>
                    </div>

                    <div className="md:col-span-7 space-y-4">
                      {/* Upload zone */}
                      <div className="border-2 border-dashed border-neutral-200 hover:border-orange-500 rounded-xl p-8 text-center bg-white cursor-pointer relative">
                        <input
                          type="file"
                          accept="image/*"
                          onChange={handleCompanionFileChange}
                          className="absolute inset-0 opacity-0 cursor-pointer"
                        />
                        <Upload className="w-10 h-10 mx-auto text-orange-500 mb-3" />
                        <h4 className="text-xs font-black text-neutral-800">Upload primary image to start</h4>
                        <p className="text-[10px] text-neutral-400 mt-1">PNG, JPG, JPEG, WEBP and GIF source files supported.</p>
                      </div>

                      {companionFiles.length > 0 && (
                        <div className="bg-neutral-50/60 border border-neutral-200 rounded-xl p-4 space-y-4">
                          <div className="flex justify-between items-center">
                            <span className="text-xs font-black text-neutral-800">Stage File Queue</span>
                            <button onClick={clearCompanionQueue} className="text-xs text-red-500 hover:underline">Clear</button>
                          </div>
                          
                          <div className="border border-neutral-200 bg-white rounded-lg flex items-center justify-center p-2 min-h-48 overflow-hidden relative">
                            <img src={companionFiles[0].preview} alt="" className="max-h-48 object-contain" referrerPolicy="no-referrer" />
                          </div>

                          {companionResultUrl && (
                            <div className="space-y-2 border-t border-neutral-200 pt-4 animate-fadeIn">
                              <h4 className="text-xs font-black text-neutral-800 flex items-center gap-1">
                                <Check className="w-4 h-4 text-emerald-500" />
                                Processed Output Ready!
                              </h4>
                              
                              <div className="flex items-center justify-between bg-white border border-neutral-200 p-2 rounded-lg">
                                <span className="text-[11px] font-mono text-neutral-600 truncate max-w-xs">{companionFiles[0].name.split('.')[0]}_processed.png</span>
                                <a
                                  href={companionResultUrl}
                                  download={`${companionFiles[0].name.split('.')[0]}_processed.png`}
                                  className="inline-flex items-center gap-1 px-3 py-1.5 bg-orange-500 text-white font-bold text-[10px] rounded hover:bg-orange-600 transition-colors"
                                >
                                  <Download className="w-3 h-3" />
                                  Download Result
                                </a>
                              </div>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Informative Help Guide dashboard card */}
        <section className="bg-neutral-900 border border-neutral-800 p-6 rounded-2xl grid grid-cols-1 md:grid-cols-3 gap-6 text-white">
          <div className="flex gap-3">
            <div className="w-6 h-6 flex items-center justify-center rounded bg-orange-500 text-neutral-950 mt-0.5 flex-shrink-0 font-extrabold text-xs">
              💡
            </div>
            <div>
              <h4 className="text-xs font-bold text-neutral-100 uppercase tracking-widest font-mono">What is WebP?</h4>
              <p className="text-[11px] text-neutral-400 mt-1.5 leading-relaxed font-sans">
                WebP is a modern image format natively optimized for fast loaders. It provides superior lossless and lossy compression weight trims, making pages up to 3x snappier.
              </p>
            </div>
          </div>

          <div className="flex gap-3">
            <div className="w-6 h-6 flex items-center justify-center rounded bg-orange-500 text-neutral-950 mt-0.5 flex-shrink-0 font-extrabold text-xs">
              🔒
            </div>
            <div>
              <h4 className="text-xs font-bold text-neutral-100 uppercase tracking-widest font-mono">Secure Offline</h4>
              <p className="text-[11px] text-neutral-400 mt-1.5 leading-relaxed font-sans">
                Online converter engines logging, harvesting and indexing personal photos pose serious privacy risks. Julfy tools operate 150kb sandbox canvases keeping files safe on-machine.
              </p>
            </div>
          </div>

          <div className="flex gap-3">
            <div className="w-6 h-6 flex items-center justify-center rounded bg-orange-500 text-neutral-950 mt-0.5 flex-shrink-0 font-extrabold text-xs">
              ⚡
            </div>
            <div>
              <h4 className="text-xs font-bold text-neutral-100 uppercase tracking-widest font-mono">Sandbox Sandbox</h4>
              <p className="text-[11px] text-neutral-400 mt-1.5 leading-relaxed font-sans">
                Complex filters and compression scales execute inside isolated web thread sandboxes, guaranteeing high responsive frame rates across small screens or low-end devices.
              </p>
            </div>
          </div>
        </section>
      </main>

      {/* Unified Aesthetic Footer with Brand Links */}
      <footer className="bg-white border-t border-neutral-200 py-8 px-6 md:px-12 text-xs text-neutral-500">
        <div className="max-w-7xl mx-auto space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pb-6 border-b border-neutral-100 text-left">
            <div className="space-y-1.5">
              <h4 className="text-xs font-black text-neutral-950 uppercase tracking-widest font-mono flex items-center gap-1.5">
                <span className="w-1 h-3 bg-orange-500 rounded-2xs"></span>
                About LearnWithJulfy
              </h4>
              <p className="text-[11px] text-neutral-400 leading-relaxed max-w-md">
                Dedicated to providing high-quality educational software, premium resource rankers, and offline-first private productivity utilities built with GPU-accelerated code.
              </p>
            </div>
            <div className="space-y-2">
              <h4 className="text-xs font-black text-neutral-950 uppercase tracking-widest font-mono">
                LearnWithJulfy Network
              </h4>
              <div className="flex flex-col sm:flex-row sm:items-center gap-x-6 gap-y-2">
                <a
                  href="https://www.youtube.com/channel/UCUQBU0hKJLCt82wwyEnf8Fw"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 font-semibold text-neutral-600 hover:text-red-500 transition-colors"
                >
                  <span className="text-base">📺</span>
                  <span className="hover:underline">LearnWithJulfy YouTube Channel</span>
                </a>
                <a
                  href="https://learnwithjulfy-platinum-ranker-6x12.vercel.app/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 font-semibold text-neutral-600 hover:text-orange-500 transition-colors"
                >
                  <span className="text-base">📚</span>
                  <span className="hover:underline">LearnWithJulfy Platinum Ranker</span>
                </a>
              </div>
            </div>
          </div>
          
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-1">
            <p className="font-medium text-neutral-400">
              &copy; 1998 - 2026 LearnWithJulfy, all rights reserved.
            </p>
            <p className="flex items-center gap-1.5 font-mono text-[10px] text-neutral-400">
              Made with <Heart className="w-3 h-3 text-red-500 fill-red-500 animate-pulse" /> for examinationthss-gif utilities
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
