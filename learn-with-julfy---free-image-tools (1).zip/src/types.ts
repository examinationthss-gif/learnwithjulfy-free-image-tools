/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type ActiveTool = 'compressor' | 'resizer' | 'meme' | 'gif-creator';

export interface ImageFile {
  id: string;
  name: string;
  file: File;
  previewUrl: string;
  originalSize: number;
  width: number;
  height: number;
}

export interface MemeText {
  id: string;
  text: string;
  x: number; // percentage (0 to 100)
  y: number; // percentage (0 to 100)
  fontSize: number;
  color: string;
  strokeColor: string;
  strokeWidth: number;
  isDragging?: boolean;
}

export interface GifFrame {
  id: string;
  previewUrl: string;
  duration: number; // delay in ms
  width: number;
  height: number;
}
