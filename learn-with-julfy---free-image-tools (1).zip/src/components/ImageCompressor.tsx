/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { Upload, Download, Sparkles, FileImage, RefreshCw, CheckCircle, Sliders, ArrowRight } from 'lucide-react';
import { ImageFile } from '../types';

export default function ImageCompressor() {
  const [images, setImages] = useState<ImageFile[]>([]);
  const [selectedImageId, setSelectedImageId] = useState<string | null>(null);
  const [compressionQuality, setCompressionQuality] = useState<number>(80);
  const [targetFormat, setTargetFormat] = useState<string>('image/jpeg');
  const [compressedResult, setCompressedResult] = useState<{
    url: string;
    size: number;
    width: number;
    height: number;
  } | null>(null);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [dragActive, setDragActive] = useState<boolean>(false);
  const [splitRatio, setSplitRatio] = useState<number>(50); // percentage 0-100 for side by side
  const fileInputRef = useRef<HTMLInputElement>(null);
  const sliderContainerRef = useRef<HTMLDivElement>(null);

  const selectedImage = images.find((img) => img.id === selectedImageId);

  // Trigger compression when settings change or different image in list is picked
  useEffect(() => {
    if (selectedImage) {
      handleCompress(selectedImage);
    } else {
      setCompressedResult(null);
    }
  }, [selectedImageId, compressionQuality, targetFormat]);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const processFiles = (files: FileList) => {
    const validImages: ImageFile[] = [];
    const proms = Array.from(files).map((file) => {
      if (!file.type.startsWith('image/')) return Promise.resolve();
      
      const id = Math.random().toString(36).substring(2, 9);
      const previewUrl = URL.createObjectURL(file);
      
      return new Promise<void>((resolve) => {
        const img = new Image();
        img.onload = () => {
          validImages.push({
            id,
            name: file.name,
            file,
            previewUrl,
            originalSize: file.size,
            width: img.width,
            height: img.height,
          });
          resolve();
        };
        img.onerror = () => {
          resolve(); // skip bad image
        };
        img.src = previewUrl;
      });
    });

    Promise.all(proms).then(() => {
      if (validImages.length > 0) {
        setImages((prev) => [...prev, ...validImages]);
        setSelectedImageId(validImages[0].id);
      }
    });
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      processFiles(e.dataTransfer.files);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      processFiles(e.target.files);
    }
  };

  const handleCompress = (sourceImage: ImageFile) => {
    setIsProcessing(true);
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = img.width;
        canvas.height = img.height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          setIsProcessing(false);
          return;
        }

        ctx.drawImage(img, 0, 0);

        // Quality calculations (scale quality to typical values)
        const qVal = compressionQuality / 100;
        const outUrl = canvas.toDataURL(targetFormat, qVal);

        // Calculate decoded base64 payload size accurately
        const head = `data:${targetFormat};base64,`;
        const approxSize = Math.round((outUrl.length - head.length) * 3 / 4);

        setCompressedResult({
          url: outUrl,
          size: approxSize,
          width: img.width,
          height: img.height,
        });
        setIsProcessing(false);
      };
      img.onerror = () => setIsProcessing(false);
      img.src = e.target?.result as string;
    };
    reader.onerror = () => setIsProcessing(false);
    reader.readAsDataURL(sourceImage.file);
  };

  const formatSize = (bytes: number): string => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
  };

  const removeImage = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setImages((prev) => prev.filter((img) => img.id !== id));
    if (selectedImageId === id) {
      const remaining = images.filter((img) => img.id !== id);
      setSelectedImageId(remaining.length > 0 ? remaining[0].id : null);
    }
  };

  const handleDownload = () => {
    if (!compressedResult || !selectedImage) return;
    const link = document.createElement('a');
    
    // Generate clean filename
    const originalNameNoExt = selectedImage.name.substring(0, selectedImage.name.lastIndexOf('.')) || selectedImage.name;
    const formatExtension = targetFormat.split('/')[1] === 'jpeg' ? 'jpg' : targetFormat.split('/')[1];
    
    link.download = `${originalNameNoExt}_compressed.${formatExtension}`;
    link.href = compressedResult.url;
    link.click();
  };

  const handleSplitMove = (clientX: number) => {
    if (!sliderContainerRef.current) return;
    const rect = sliderContainerRef.current.getBoundingClientRect();
    const x = clientX - rect.left;
    const perc = Math.max(0, Math.min(100, (x / rect.width) * 100));
    setSplitRatio(perc);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (e.touches && e.touches[0]) {
      handleSplitMove(e.touches[0].clientX);
    }
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (e.buttons === 1) { // Left-click dragged
      handleSplitMove(e.clientX);
    }
  };

  // Preset quick qualities
  const applyPresetQuality = (quality: number) => {
    setCompressionQuality(quality);
  };

  return (
    <div id="image-compressor-tab" className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
      {/* Sidebar Controls - Left Column (lg:col-span-5) */}
      <div className="lg:col-span-5 space-y-6">
        <div className="bg-white rounded-2xl border border-gray-100 p-6 shadow-xs">
          <h2 className="text-lg font-semibold text-gray-900 mb-2 flex items-center gap-2">
            <Sliders className="w-5 h-5 text-indigo-600" />
            1. Configure Settings
          </h2>
          <p className="text-sm text-gray-500 mb-6">
            Optimize your images to save bandwidth and storage without reducing visual crispness.
          </p>

          {/* Formats Selector */}
          <div className="mb-6">
            <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-2">
              Target Format
            </label>
            <div className="grid grid-cols-3 gap-2">
              {[
                { label: 'JPG / JPEG', mime: 'image/jpeg' },
                { label: 'WEBP (Web-optimized)', mime: 'image/webp' },
                { label: 'PNG (Lossy Recast)', mime: 'image/png' },
              ].map((fmt) => (
                <button
                  key={fmt.mime}
                  id={`btn-format-${fmt.mime}`}
                  type="button"
                  onClick={() => setTargetFormat(fmt.mime)}
                  className={`px-3 py-2 text-xs font-medium rounded-xl border transition-all ${
                    targetFormat === fmt.mime
                      ? 'border-indigo-600 bg-indigo-50 text-indigo-700 font-semibold shadow-2xs'
                      : 'border-gray-200 hover:border-gray-300 text-gray-600 hover:bg-gray-50'
                  }`}
                >
                  {fmt.label.split(' ')[0]}
                </button>
              ))}
            </div>
            <p className="text-[10px] text-gray-400 mt-1.5 leading-relaxed">
              {targetFormat === 'image/webp' && '✨ WEBP provides cutting-edge high-fidelity with extremely slim file sizes.'}
              {targetFormat === 'image/jpeg' && 'JPEG is widely compatible across all computers, platforms, and devices.'}
              {targetFormat === 'image/png' && 'Redraws transparent regions; useful to trim down bloated camera photos.'}
            </p>
          </div>

          {/* Slider */}
          <div className="mb-6">
            <div className="flex justify-between items-center mb-2">
              <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider">
                JPEG/WEBP Quality
              </label>
              <span className="text-sm font-mono font-semibold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-lg border border-indigo-100">
                {compressionQuality}%
              </span>
            </div>
            <input
              id="quality-slider"
              type="range"
              min="5"
              max="100"
              step="1"
              value={compressionQuality}
              onChange={(e) => setCompressionQuality(Number(e.target.value))}
              className="w-full h-2 bg-gray-100 rounded-lg appearance-none cursor-pointer accent-indigo-600"
            />
            <div className="flex justify-between text-[10px] text-gray-400 mt-1 font-mono">
              <span>Max Compress (5%)</span>
              <span>Balanced (80%)</span>
              <span>Ultra Crisp (100%)</span>
            </div>

            {/* Quick Presets */}
            <div className="flex gap-2 mt-4">
              {[
                { val: 40, label: 'Eco Friendly (Low Size)' },
                { val: 75, label: 'Balanced (Recommended)' },
                { val: 95, label: 'Highest Quality' },
              ].map((pres) => (
                <button
                  key={pres.val}
                  type="button"
                  onClick={() => applyPresetQuality(pres.val)}
                  className={`text-[10px] font-medium px-2 py-1 rounded-md border transition-all ${
                    compressionQuality === pres.val
                      ? 'bg-indigo-600 border-indigo-600 text-white'
                      : 'bg-white border-gray-200 text-gray-500 hover:border-gray-300 hover:text-gray-700'
                  }`}
                >
                  {pres.val}%
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Upload Container / Files List */}
        <div className="bg-white rounded-2xl border border-gray-100 p-6 shadow-xs">
          <div className="flex justify-between items-center mb-3">
            <h3 className="text-sm font-semibold text-gray-800">Files Queue ({images.length})</h3>
            {images.length > 0 && (
              <button
                id="btn-clear-all"
                type="button"
                onClick={() => {
                  setImages([]);
                  setSelectedImageId(null);
                }}
                className="text-xs text-red-500 hover:red-600 hover:underline"
              >
                Clear all
              </button>
            )}
          </div>

          <div
            id="compressor-dropzone"
            onDragEnter={handleDrag}
            onDragOver={handleDrag}
            onDragLeave={handleDrag}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
            className={`border-2 border-dashed rounded-xl p-5 text-center cursor-pointer transition-all ${
              dragActive
                ? 'border-indigo-500 bg-indigo-50/50 scale-[0.99] shadow-inner'
                : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50/30'
            }`}
          >
            <input
              id="file-selector-input"
              ref={fileInputRef}
              type="file"
              accept="image/*"
              multiple
              onChange={handleFileChange}
              className="hidden"
            />
            <div className="inline-flex items-center justify-center w-10 h-10 rounded-full bg-gray-50 text-gray-500 mb-2">
              <Upload className="w-5 h-5 text-indigo-500" />
            </div>
            <p className="text-xs font-semibold text-gray-700">Click to import / Drag images here</p>
            <p className="text-[10px] text-gray-400 mt-1 font-mono">PNG, JPG, JPEG, WEBP, GIF, SVG</p>
          </div>

          {/* List queue */}
          {images.length > 0 && (
            <div className="mt-4 max-h-[220px] overflow-y-auto space-y-1.5 pr-1">
              {images.map((img) => (
                <div
                  key={img.id}
                  id={`queue-item-${img.id}`}
                  onClick={() => setSelectedImageId(img.id)}
                  className={`group relative flex items-center justify-between p-2 rounded-xl border text-left cursor-pointer transition-all ${
                    selectedImageId === img.id
                      ? 'border-indigo-600 bg-indigo-50/30 ring-1 ring-indigo-500'
                      : 'border-gray-100 hover:border-gray-200 bg-white'
                  }`}
                >
                  <div className="flex items-center gap-2 min-w-0 pr-6">
                    <img
                      src={img.previewUrl}
                      alt={img.name}
                      referrerPolicy="no-referrer"
                      className="w-10 h-10 object-cover rounded-lg border border-gray-100 flex-shrink-0"
                    />
                    <div className="min-w-0">
                      <p className="text-xs font-semibold text-gray-800 truncate leading-snug">
                        {img.name}
                      </p>
                      <p className="text-[10px] font-mono text-gray-400 mt-0.5">
                        {formatSize(img.originalSize)} ({img.width}x{img.height})
                      </p>
                    </div>
                  </div>
                  <button
                    id={`btn-remove-${img.id}`}
                    type="button"
                    onClick={(e) => removeImage(img.id, e)}
                    className="absolute right-2 top-1/2 -translate-y-1/2 w-5 h-5 flex items-center justify-center text-gray-300 hover:text-red-500 rounded-md transition-colors"
                  >
                    &times;
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Primary Split View Preview and Stats - Right Column (lg:col-span-7) */}
      <div className="lg:col-span-7 space-y-6">
        {selectedImage ? (
          <>
            {/* Live Stats Board */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="bg-white rounded-xl border border-gray-100 p-4 shadow-2xs">
                <p className="text-[10px] font-medium text-gray-400 uppercase tracking-widest">Original Size</p>
                <p className="text-lg font-mono font-bold text-gray-700 mt-1">{formatSize(selectedImage.originalSize)}</p>
                <p className="text-[10px] text-gray-400 font-mono mt-0.5">{selectedImage.width} &times; {selectedImage.height} px</p>
              </div>

              <div className="bg-white rounded-xl border border-gray-100 p-4 shadow-2xs">
                <p className="text-[10px] font-medium text-gray-400 uppercase tracking-widest flex items-center gap-1">
                  Optimized Size
                  {isProcessing && <RefreshCw className="w-3 h-3 text-indigo-500 animate-spin" />}
                </p>
                <p className="text-lg font-mono font-bold text-indigo-600 mt-1">
                  {compressedResult ? formatSize(compressedResult.size) : 'Calculating...'}
                </p>
                <p className="text-[10px] text-indigo-500 font-mono mt-0.5 uppercase tracking-wide font-medium flex items-center gap-0.5">
                  {compressedResult && compressedResult.size < selectedImage.originalSize ? '🎉 Highly Compressed' : 'Ready'}
                </p>
              </div>

              <div className="bg-indigo-600 rounded-xl p-4 shadow-xs text-white">
                <p className="text-[10px] font-medium text-indigo-200 uppercase tracking-widest">Storage Saved</p>
                <p className="text-2xl font-black font-mono mt-0.5">
                  {compressedResult
                    ? selectedImage.originalSize > compressedResult.size
                      ? `${(((selectedImage.originalSize - compressedResult.size) / selectedImage.originalSize) * 100).toFixed(0)}%`
                      : '0%'
                    : '--'}
                </p>
                <p className="text-[10px] text-indigo-200 font-mono mt-0.5">
                  {compressedResult && selectedImage.originalSize > compressedResult.size
                    ? `节省 ${formatSize(selectedImage.originalSize - compressedResult.size)} space!`
                    : 'Optimal quality configuration'}
                </p>
              </div>
            </div>

            {/* Split Slider Preview Window */}
            <div className="bg-white rounded-2xl border border-gray-100 p-4 shadow-xs">
              <div className="flex justify-between items-center mb-3">
                <span className="text-xs font-semibold text-gray-700 flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                  Live Preview: Swipe/Drag Slider to Compare
                </span>
                <span className="text-[10px] bg-slate-100 text-slate-600 font-mono px-2 py-0.5 rounded">
                  Left: Original | Right: Optimized
                </span>
              </div>

              {/* Slider viewport */}
              <div
                ref={sliderContainerRef}
                onMouseMove={handleMouseMove}
                onTouchMove={handleTouchMove}
                className="relative h-[380px] w-full bg-slate-50 border border-slate-100 rounded-xl overflow-hidden select-none cursor-ew-resize flex items-center justify-center"
              >
                {/* Optimized Result (Right / Background) */}
                {compressedResult ? (
                  <img
                    src={compressedResult.url}
                    alt="Optimized preview"
                    referrerPolicy="no-referrer"
                    className="absolute max-h-[360px] max-w-[95%] object-contain pointer-events-none"
                  />
                ) : (
                  <div className="text-center text-gray-300">
                    <RefreshCw className="w-8 h-8 mx-auto animate-spin mb-2" />
                    Calculating...
                  </div>
                )}

                {/* Left Original Clipping Mask layer */}
                <div
                  className="absolute left-0 top-0 bottom-0 overflow-hidden flex items-center justify-center"
                  style={{ width: `${splitRatio}%` }}
                >
                  <div
                    className="absolute h-full w-full flex items-center justify-center pointer-events-none"
                    style={{ width: sliderContainerRef.current?.getBoundingClientRect().width || '100vw' }}
                  >
                    <img
                      src={selectedImage.previewUrl}
                      alt="Original preview"
                      referrerPolicy="no-referrer"
                      className="max-h-[360px] max-w-[95%] object-contain"
                    />
                  </div>
                </div>

                {/* Division bar handle */}
                <div
                  className="absolute top-0 bottom-0 w-0.5 bg-white shadow-[0_0_10px_rgba(0,0,0,0.5)] z-10 pointer-events-none"
                  style={{ left: `${splitRatio}%` }}
                >
                  <div className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-6 h-6 rounded-full bg-white text-slate-800 border-2 border-indigo-600 flex items-center justify-center shadow-md text-[10px] font-bold font-mono">
                    ↔
                  </div>
                </div>
              </div>

              {/* Slider Instructions */}
              <div className="mt-3 flex items-center justify-between">
                <span className="text-[10px] text-gray-400 font-mono">
                  W: {selectedImage.width}px &times; H: {selectedImage.height}px
                </span>
                <button
                  id="btn-trigger-download"
                  type="button"
                  onClick={handleDownload}
                  disabled={isProcessing || !compressedResult}
                  className="inline-flex items-center gap-1.5 px-4 py-2 bg-indigo-600 text-white hover:bg-indigo-700 disabled:opacity-50 text-xs font-semibold rounded-xl shadow-md transition-all"
                >
                  <Download className="w-3.5 h-3.5" />
                  Download Optimized Image
                </button>
              </div>
            </div>
          </>
        ) : (
          /* Empty State */
          <div className="bg-slate-50 border border-dashed border-gray-200 rounded-3xl p-12 text-center h-[480px] flex flex-col justify-center items-center">
            <div className="w-16 h-16 bg-white border border-gray-100 flex items-center justify-center rounded-2xl shadow-sm text-gray-400 mb-4 animate-pulse">
              <FileImage className="w-8 h-8 text-indigo-400" />
            </div>
            <h3 className="text-base font-bold text-gray-800 mb-1">No Image Imported</h3>
            <p className="text-xs text-gray-500 max-w-sm mb-4 leading-relaxed">
              Import one or more images under the Files Queue to adjust size metrics, tune quality compressions, and see real-time side-by-side previews!
            </p>
            <button
              id="empty-trigger-btn"
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="inline-flex items-center gap-1.5 px-4 py-2.5 bg-indigo-600 text-white text-xs font-semibold rounded-xl hover:bg-indigo-700 transition-colors shadow-sm"
            >
              <Upload className="w-3.5 h-3.5" />
              Upload Image to Start
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
