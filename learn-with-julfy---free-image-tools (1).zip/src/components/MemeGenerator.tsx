/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { Type, Download, Upload, Trash2, Plus, Eye, Sliders, Palette, Smartphone, RefreshCw } from 'lucide-react';
import { ImageFile, MemeText } from '../types';

export default function MemeGenerator() {
  const [images, setImages] = useState<ImageFile[]>([]);
  const [selectedImageId, setSelectedImageId] = useState<string | null>(null);

  // Texts State (Supports unlimited layers!)
  const [textLayers, setTextLayers] = useState<MemeText[]>([
    { id: 'top', text: 'TOP TEXT HERE', x: 50, y: 12, fontSize: 36, color: '#ffffff', strokeColor: '#000000', strokeWidth: 4 },
    { id: 'bottom', text: 'BOTTOM TEXT HERE', x: 50, y: 88, fontSize: 36, color: '#ffffff', strokeColor: '#000000', strokeWidth: 4 }
  ]);
  const [activeLayerId, setActiveLayerId] = useState<string>('top');

  // Filter Adjustments
  const [filterPreset, setFilterPreset] = useState<string>('none');
  const [brightness, setBrightness] = useState<number>(100); // 0 to 200
  const [contrast, setContrast] = useState<number>(100); // 0 to 200
  const [saturation, setSaturation] = useState<number>(100); // 0 to 200
  const [blur, setBlur] = useState<number>(0); // 0 to 20

  const [downloadPreviewUrl, setDownloadPreviewUrl] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const selectedImage = images.find((i) => i.id === selectedImageId);
  const activeLayer = textLayers.find((l) => l.id === activeLayerId);

  // Set filter slider values when a preset is selected
  useEffect(() => {
    if (filterPreset === 'none') {
      setBrightness(100); setContrast(100); setSaturation(100); setBlur(0);
    } else if (filterPreset === 'grayscale') {
      setBrightness(100); setContrast(110); setSaturation(0); setBlur(0);
    } else if (filterPreset === 'sepia') {
      setBrightness(100); setContrast(90); setSaturation(80); setBlur(0);
    } else if (filterPreset === 'vintage') {
      setBrightness(95); setContrast(85); setSaturation(130); setBlur(0);
    } else if (filterPreset === 'cool') {
      setBrightness(105); setContrast(120); setSaturation(140); setBlur(0);
    } else if (filterPreset === 'blur') {
      setBrightness(100); setContrast(100); setSaturation(100); setBlur(3);
    }
  }, [filterPreset]);

  // Redraw complete canvas upon changes
  useEffect(() => {
    if (selectedImage) {
      drawMeme();
    }
  }, [selectedImage, textLayers, brightness, contrast, saturation, blur]);

  const drawMeme = () => {
    const canvas = canvasRef.current;
    if (!canvas || !selectedImage) return;

    const img = new Image();
    img.onload = () => {
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      // Match canvas dimensions to the loaded image
      canvas.width = img.width;
      canvas.height = img.height;

      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // 1. Apply image filter parameters
      let filterString = `brightness(${brightness}%) contrast(${contrast}%) saturate(${saturation}%)`;
      if (blur > 0) {
        // scale blur relatively to image width
        const relativeBlur = (blur * canvas.width) / 800;
        filterString += ` blur(${relativeBlur.toFixed(1)}px)`;
      }

      // Grayscale/sepia presets are mixed in via saturation metrics, but just in case:
      if (filterPreset === 'grayscale') filterString += ' grayscale(100%)';
      if (filterPreset === 'sepia') filterString += ' sepia(100%)';

      ctx.filter = filterString;

      // Draw filtered image
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);

      // Disable filters for rendering text layers correctly
      ctx.filter = 'none';

      // 2. Render Text Layers
      textLayers.forEach((layer) => {
        // Scale font size proportionally to canvas width (assuming standard 800px base)
        const proportionalSize = Math.round((layer.fontSize * canvas.width) / 700);

        ctx.font = `bold ${proportionalSize}px Impact, "Arial Black", sans-serif`;
        ctx.fillStyle = layer.color;
        ctx.strokeStyle = layer.strokeColor;
        ctx.lineWidth = Math.max(1, Math.round((layer.strokeWidth * canvas.width) / 700));
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';

        // Calculate absolute position on canvas from percentage values
        const absX = (layer.x / 100) * canvas.width;
        const absY = (layer.y / 100) * canvas.height;

        // Render outline first
        if (layer.strokeWidth > 0) {
          ctx.strokeText(layer.text, absX, absY);
        }
        // Render solid fill next
        ctx.fillText(layer.text, absX, absY);
      });

      // Save processed preview image
      setDownloadPreviewUrl(canvas.toDataURL('image/png'));
    };
    img.src = selectedImage.previewUrl;
  };

  const handleStageClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!containerRef.current || textLayers.length === 0) return;

    const rect = containerRef.current.getBoundingClientRect();
    const xPct = ((e.clientX - rect.left) / rect.width) * 100;
    const yPct = ((e.clientY - rect.top) / rect.height) * 100;

    // Detect closest text layer clicked
    let closestLayer: MemeText | null = null;
    let minDistance = 15; // click sensitivity radius in percentage coordinates

    textLayers.forEach((layer) => {
      const distance = Math.sqrt(Math.pow(layer.x - xPct, 2) + Math.pow(layer.y - yPct, 2));
      if (distance < minDistance) {
        minDistance = distance;
        closestLayer = layer;
      }
    });

    if (closestLayer) {
      setActiveLayerId((closestLayer as MemeText).id);
      
      // Setup dragging state
      const startDrag = (moveEvent: MouseEvent) => {
        const mvRect = containerRef.current!.getBoundingClientRect();
        const mvX = Math.max(0, Math.min(100, ((moveEvent.clientX - mvRect.left) / mvRect.width) * 100));
        const mvY = Math.max(0, Math.min(100, ((moveEvent.clientY - mvRect.top) / mvRect.height) * 100));

        setTextLayers((prev) =>
          prev.map((l) => (l.id === (closestLayer as MemeText).id ? { ...l, x: mvX, y: mvY } : l))
        );
      };

      const stopDrag = () => {
        window.removeEventListener('mousemove', startDrag);
        window.removeEventListener('mouseup', stopDrag);
      };

      window.addEventListener('mousemove', startDrag);
      window.addEventListener('mouseup', stopDrag);
    }
  };

  const handleAddLayer = () => {
    const id = Math.random().toString(36).substring(2, 7);
    const newLayer: MemeText = {
      id,
      text: 'NEW CAPTION',
      x: 50,
      y: 50,
      fontSize: 28,
      color: '#ffffff',
      strokeColor: '#000000',
      strokeWidth: 3,
    };
    setTextLayers((prev) => [...prev, newLayer]);
    setActiveLayerId(id);
  };

  const handleDeleteLayer = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setTextLayers((prev) => prev.filter((l) => l.id !== id));
    if (activeLayerId === id) {
      const remaining = textLayers.filter((l) => l.id !== id);
      setActiveLayerId(remaining.length > 0 ? remaining[0].id : '');
    }
  };

  const handleUpdateActiveLayer = (field: keyof MemeText, value: any) => {
    setTextLayers((prev) =>
      prev.map((l) => (l.id === activeLayerId ? { ...l, [field]: value } : l))
    );
  };

  const handleDownload = () => {
    if (!downloadPreviewUrl || !selectedImage) return;
    const link = document.createElement('a');
    const originalName = selectedImage.name.substring(0, selectedImage.name.lastIndexOf('.')) || selectedImage.name;
    link.download = `${originalName}_meme.png`;
    link.href = downloadPreviewUrl;
    link.click();
  };

  const processUploadFiles = (files: FileList) => {
    const loaded: ImageFile[] = [];
    const proms = Array.from(files).map((file) => {
      if (!file.type.startsWith('image/')) return Promise.resolve();
      const id = Math.random().toString(36).substring(2, 9);
      const url = URL.createObjectURL(file);
      return new Promise<void>((resolve) => {
        const img = new Image();
        img.onload = () => {
          loaded.push({
            id,
            name: file.name,
            file,
            previewUrl: url,
            originalSize: file.size,
            width: img.width,
            height: img.height,
          });
          resolve();
        };
        img.onerror = () => resolve();
        img.src = url;
      });
    });

    Promise.all(proms).then(() => {
      if (loaded.length > 0) {
        setImages((prev) => [...prev, ...loaded]);
        setSelectedImageId(loaded[0].id);
      }
    });
  };

  return (
    <div id="meme-generator-tab" className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
      {/* Settings Panel - Left Column */}
      <div className="lg:col-span-5 space-y-6">
        <div className="bg-white rounded-2xl border border-gray-100 p-6 shadow-xs">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-sm font-semibold text-gray-700 uppercase tracking-wider flex items-center gap-1.5">
              <Type className="w-4 h-4 text-indigo-600" />
              1. Add & Position Captions
            </h2>
            <button
              id="btn-add-meme-text"
              type="button"
              disabled={!selectedImage}
              onClick={handleAddLayer}
              className="inline-flex items-center gap-1 text-[11px] font-bold px-2.5 py-1.5 bg-indigo-50 border border-indigo-100 text-indigo-700 hover:bg-indigo-100/60 rounded-lg disabled:opacity-50 transition-colors"
            >
              <Plus className="w-3.5 h-3.5" />
              Add Layer
            </button>
          </div>

          {/* List of text layers */}
          <div className="space-y-2 mb-6">
            {textLayers.map((layer) => (
              <div
                key={layer.id}
                onClick={() => setActiveLayerId(layer.id)}
                className={`relative flex items-center justify-between p-2 rounded-xl border text-left cursor-pointer transition-all ${
                  activeLayerId === layer.id
                    ? 'border-indigo-600 bg-indigo-50/20'
                    : 'border-gray-100 hover:border-gray-200 bg-white'
                }`}
              >
                <div className="min-w-0 flex items-center gap-2.5">
                  <div className="w-5 h-5 flex items-center justify-center rounded bg-slate-100 text-[10px] font-bold text-slate-500 font-mono">
                    {layer.id.substring(0, 3).toUpperCase()}
                  </div>
                  <p className="text-xs font-semibold text-gray-800 truncate pr-6">
                    {layer.text || '「Empty Caption」'}
                  </p>
                </div>
                {textLayers.length > 1 && (
                  <button
                    id={`btn-del-layer-${layer.id}`}
                    type="button"
                    onClick={(e) => handleDeleteLayer(layer.id, e)}
                    className="text-gray-300 hover:text-red-500 p-1 rounded hover:bg-gray-50 flex items-center justify-center"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            ))}
          </div>

          {/* Active caption settings */}
          {activeLayer && selectedImage && (
            <div className="bg-slate-50 border border-slate-100 rounded-xl p-4 space-y-4">
              <div>
                <label className="block text-[10px] font-semibold text-slate-400 uppercase tracking-widest mb-1.5">
                  Selected Caption Content
                </label>
                <input
                  id="meme-layer-text-input"
                  type="text"
                  value={activeLayer.text}
                  onChange={(e) => handleUpdateActiveLayer('text', e.target.value)}
                  className="w-full px-3 py-2 border border-gray-200 bg-white rounded-lg focus:ring-2 focus:ring-indigo-500 text-sm font-semibold text-gray-800"
                />
              </div>

              {/* Slider Font resizing */}
              <div>
                <div className="flex justify-between items-center text-[10px] font-semibold text-slate-400 uppercase tracking-wide mb-1">
                  <span>Font Size</span>
                  <span className="font-mono text-xs font-bold text-indigo-600">{activeLayer.fontSize}px</span>
                </div>
                <input
                  id="slider-font-size"
                  type="range"
                  min="8"
                  max="100"
                  value={activeLayer.fontSize}
                  onChange={(e) => handleUpdateActiveLayer('fontSize', Number(e.target.value))}
                  className="w-full accent-indigo-600"
                />
              </div>

              {/* Coloring row */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="flex justify-between items-center text-[10px] font-semibold text-slate-400 uppercase tracking-wide mb-1">
                    <span>Fill Color</span>
                    <span className="font-mono text-[9px] text-gray-400">{activeLayer.color}</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <input
                      id="color-picker-fill"
                      type="color"
                      value={activeLayer.color}
                      onChange={(e) => handleUpdateActiveLayer('color', e.target.value)}
                      className="w-8 h-8 rounded border-none cursor-pointer overflow-hidden p-0 bg-transparent flex-shrink-0"
                    />
                    <input
                      type="text"
                      value={activeLayer.color}
                      onChange={(e) => handleUpdateActiveLayer('color', e.target.value)}
                      className="w-full text-xs font-mono px-2 py-1.5 border border-gray-200 bg-white rounded-lg"
                    />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between items-center text-[10px] font-semibold text-slate-400 uppercase tracking-wide mb-1">
                    <span>Stroke Color</span>
                    <span className="font-mono text-[9px] text-gray-400">{activeLayer.strokeColor}</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <input
                      id="color-picker-outline"
                      type="color"
                      value={activeLayer.strokeColor}
                      onChange={(e) => handleUpdateActiveLayer('strokeColor', e.target.value)}
                      className="w-8 h-8 rounded border-none cursor-pointer overflow-hidden p-0 bg-transparent flex-shrink-0"
                    />
                    <input
                      type="text"
                      value={activeLayer.strokeColor}
                      onChange={(e) => handleUpdateActiveLayer('strokeColor', e.target.value)}
                      className="w-full text-xs font-mono px-2 py-1.5 border border-gray-200 bg-white rounded-lg"
                    />
                  </div>
                </div>
              </div>

              {/* Slider Outline thickness */}
              <div>
                <div className="flex justify-between items-center text-[10px] font-semibold text-slate-400 uppercase tracking-wide mb-1">
                  <span>Outline Thickness</span>
                  <span className="font-mono text-xs font-bold text-indigo-600">{activeLayer.strokeWidth}px</span>
                </div>
                <input
                  id="slider-outline-width"
                  type="range"
                  min="0"
                  max="12"
                  value={activeLayer.strokeWidth}
                  onChange={(e) => handleUpdateActiveLayer('strokeWidth', Number(e.target.value))}
                  className="w-full accent-indigo-600"
                />
              </div>
            </div>
          )}
        </div>

        {/* Filter Sliders & Presets Controls */}
        <div className="bg-white rounded-2xl border border-gray-100 p-6 shadow-xs">
          <h3 className="text-sm font-semibold text-gray-700 uppercase tracking-wider flex items-center gap-1.5 mb-4">
            <Sliders className="w-4 h-4 text-indigo-600" />
            2. Filter Studio
          </h3>

          <div className="mb-4">
            <span className="block text-[10px] font-semibold text-gray-400 uppercase mb-2">Preset Filters</span>
            <div className="grid grid-cols-3 gap-1.5">
              {[
                { id: 'none', label: 'Original' },
                { id: 'grayscale', label: 'Grayscale' },
                { id: 'sepia', label: 'Vintage Sepia' },
                { id: 'vintage', label: 'Sunset Glow' },
                { id: 'cool', label: 'Retro Cool' },
                { id: 'blur', label: 'Dreamy Blur' },
              ].map((filter) => (
                <button
                  key={filter.id}
                  type="button"
                  disabled={!selectedImage}
                  onClick={() => setFilterPreset(filter.id)}
                  className={`text-[10px] py-1.5 px-2 font-semibold border rounded-lg transition-all ${
                    filterPreset === filter.id && selectedImage
                      ? 'bg-indigo-600 border-indigo-600 text-white font-bold'
                      : 'bg-white border-gray-200 text-gray-600 hover:border-gray-300 hover:bg-gray-50'
                  }`}
                >
                  {filter.label}
                </button>
              ))}
            </div>
          </div>

          {/* Granular Sliders */}
          <div className="space-y-4 pt-2">
            <div>
              <div className="flex justify-between font-mono text-[10px] text-gray-500 mb-1">
                <span>Brightness</span>
                <span>{brightness}%</span>
              </div>
              <input
                id="slider-prop-brightness"
                type="range"
                min="30"
                max="200"
                disabled={!selectedImage}
                value={brightness}
                onChange={(e) => setBrightness(Number(e.target.value))}
                className="w-full accent-indigo-600 cursor-pointer disabled:opacity-45"
              />
            </div>

            <div>
              <div className="flex justify-between font-mono text-[10px] text-gray-500 mb-1">
                <span>Contrast</span>
                <span>{contrast}%</span>
              </div>
              <input
                id="slider-prop-contrast"
                type="range"
                min="30"
                max="200"
                disabled={!selectedImage}
                value={contrast}
                onChange={(e) => setContrast(Number(e.target.value))}
                className="w-full accent-indigo-600 cursor-pointer disabled:opacity-45"
              />
            </div>

            <div>
              <div className="flex justify-between font-mono text-[10px] text-gray-500 mb-1">
                <span>Saturation</span>
                <span>{saturation}%</span>
              </div>
              <input
                id="slider-prop-saturation"
                type="range"
                min="0"
                max="200"
                disabled={!selectedImage}
                value={saturation}
                onChange={(e) => setSaturation(Number(e.target.value))}
                className="w-full accent-indigo-600 cursor-pointer disabled:opacity-45"
              />
            </div>

            <div>
              <div className="flex justify-between font-mono text-[10px] text-gray-500 mb-1">
                <span>Blur Blur Effect</span>
                <span>{blur} / 20</span>
              </div>
              <input
                id="slider-prop-blur"
                type="range"
                min="0"
                max="10"
                disabled={!selectedImage}
                value={blur}
                onChange={(e) => setBlur(Number(e.target.value))}
                className="w-full accent-indigo-600 cursor-pointer disabled:opacity-45"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Workspace Area - Right Column */}
      <div className="lg:col-span-7 space-y-6">
        {selectedImage ? (
          <>
            <div className="bg-white rounded-2xl border border-gray-100 p-5 shadow-xs">
              <div className="flex justify-between items-center mb-3">
                <span className="text-xs font-semibold text-gray-700 flex items-center gap-1.5">
                  <Palette className="w-4 h-4 text-indigo-500" />
                  Meme Canvas Stage: Drag Captions freely!
                </span>
                <span className="text-[10px] bg-indigo-50 text-indigo-600 font-mono px-2 py-0.5 rounded">
                  {selectedImage.width} &times; {selectedImage.height} Full-res render
                </span>
              </div>

              {/* Standard Hidden Canvas */}
              <canvas ref={canvasRef} className="hidden" />

              {/* Working View Area with drag capabilities */}
              <div
                ref={containerRef}
                onMouseDown={handleStageClick}
                className="relative h-[420px] w-full bg-slate-50 border border-slate-100 rounded-xl flex items-center justify-center overflow-hidden cursor-move select-none"
              >
                {/* Master preview wrapper containing image and text layers aligned as percentages */}
                <div className="relative max-h-[400px] max-w-[95%] flex items-center justify-center">
                  <img
                    id="meme-canvas-source-img"
                    src={selectedImage.previewUrl}
                    alt="Meme source preview"
                    referrerPolicy="no-referrer"
                    className="max-h-[380px] w-auto max-w-full object-contain pointer-events-none"
                    style={{
                      filter: `brightness(${brightness}%) contrast(${contrast}%) saturate(${saturation}%) blur(${blur * 1.5}px) ${
                        filterPreset === 'grayscale' ? 'grayscale(100%)' : ''
                      } ${filterPreset === 'sepia' ? 'sepia(100%)' : ''}`
                    }}
                  />

                  {/* Absolute Text overlays matching percentage positions */}
                  {textLayers.map((layer) => (
                    <div
                      key={layer.id}
                      className={`absolute px-2 text-center pointer-events-none transform -translate-x-1/2 -translate-y-1/2 select-none select-words`}
                      style={{
                        left: `${layer.x}%`,
                        top: `${layer.y}%`,
                        fontSize: `${layer.fontSize * 0.35}px`, // scaling factor for editor container viewport representation
                        color: layer.color,
                        fontWeight: 'bold',
                        fontFamily: 'Impact, "Arial Black", sans-serif',
                        textShadow: layer.strokeWidth > 0 
                          ? `-${layer.strokeWidth * 0.5}px -${layer.strokeWidth * 0.5}px 0 ${layer.strokeColor}, 
                             ${layer.strokeWidth * 0.5}px -${layer.strokeWidth * 0.5}px 0 ${layer.strokeColor}, 
                             -${layer.strokeWidth * 0.5}px ${layer.strokeWidth * 0.5}px 0 ${layer.strokeColor}, 
                             ${layer.strokeWidth * 0.5}px ${layer.strokeWidth * 0.5}px 0 ${layer.strokeColor}, 
                             0px ${layer.strokeWidth}px 5px rgba(0,0,0,0.4)`
                          : '0px 2px 4px rgba(0,0,0,0.5)',
                        border: activeLayerId === layer.id ? '1.5px dashed rgba(79, 70, 229, 0.65)' : 'none',
                        background: activeLayerId === layer.id ? 'rgba(79, 70, 229, 0.08)' : 'transparent',
                        borderRadius: '4px',
                        padding: '4px 8px',
                      }}
                    >
                      {layer.text}
                    </div>
                  ))}
                </div>
              </div>

              <div className="mt-4 flex items-center justify-between">
                <span className="text-[10px] text-gray-400 font-mono">
                  ✨ Drag text elements directly in the box above to slide their positions!
                </span>
                <button
                  id="btn-trigger-meme-download"
                  type="button"
                  onClick={handleDownload}
                  className="inline-flex items-center gap-1.5 px-4 py-2.5 bg-indigo-600 text-white rounded-xl text-xs font-semibold shadow-md hover:bg-indigo-700 transition-all font-sans"
                >
                  <Download className="w-3.5 h-3.5" />
                  Generate & Download Meme
                </button>
              </div>
            </div>

            {/* Selector list of images */}
            <div className="bg-white rounded-xl border border-gray-100 p-4 shadow-3xs flex items-center justify-between">
              <span className="text-xs font-semibold text-gray-700 flex items-center gap-2">
                <Smartphone className="w-4 h-4 text-gray-400" />
                Change Working Image:
              </span>
              <div className="flex gap-2">
                {images.map((img) => (
                  <button
                    key={img.id}
                    type="button"
                    onClick={() => setSelectedImageId(img.id)}
                    className={`w-10 h-10 border-2 rounded-lg overflow-hidden transition-all ${
                      selectedImageId === img.id ? 'border-indigo-600 scale-95 shadow-xs' : 'border-gray-100'
                    }`}
                  >
                    <img src={img.previewUrl} alt="" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                  </button>
                ))}
              </div>
            </div>
          </>
        ) : (
          /* Empty Meme State */
          <div className="bg-slate-50 border border-dashed border-gray-200 rounded-3xl p-12 text-center h-[520px] flex flex-col justify-center items-center">
            <div className="w-16 h-16 bg-white border border-gray-100 rounded-2xl flex items-center justify-center text-gray-400 shadow-sm animate-pulse mb-4">
              <Type className="w-8 h-8 text-indigo-400" />
            </div>
            <h3 className="text-base font-bold text-gray-800 mb-1">Meme Editor & Filter Studio</h3>
            <p className="text-xs text-gray-500 max-w-sm mb-4 leading-relaxed">
              Upload templates, configure custom subtitle colors, and brush filters inside our in-browser canvas!
            </p>
            <div
              onClick={() => fileInputRef.current?.click()}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 cursor-pointer text-white text-xs font-semibold rounded-xl inline-flex items-center gap-1.5 shadow-sm"
            >
              <Upload className="w-3.5 h-3.5" />
              Upload Photo Template
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                multiple
                onChange={(e) => e.target.files && processUploadFiles(e.target.files)}
                className="hidden"
              />
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
