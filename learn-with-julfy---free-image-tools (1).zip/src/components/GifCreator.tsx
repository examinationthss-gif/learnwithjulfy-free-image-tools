/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, Trash2, ArrowLeft, ArrowRight, Video, Download, Upload, RefreshCw, Layers, CheckCircle } from 'lucide-react';
import gifshot from 'gifshot';
import { GifFrame } from '../types';

export default function GifCreator() {
  const [frames, setFrames] = useState<GifFrame[]>([]);
  const [gifWidth, setGifWidth] = useState<number>(400);
  const [gifHeight, setGifHeight] = useState<number>(400);
  const [globalDelay, setGlobalDelay] = useState<number>(300); // ms per frame

  // Live Slot loop player state
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [currentFrameIndex, setCurrentFrameIndex] = useState<number>(0);
  
  // Compilation output states
  const [isCompiling, setIsCompiling] = useState<boolean>(false);
  const [compiledGifUrl, setCompiledGifUrl] = useState<string | null>(null);
  const [compilationProgress, setCompilationProgress] = useState<string>('');

  const fileInputRef = useRef<HTMLInputElement>(null);
  const playerTimerRef = useRef<any>(null);

  // Live slideshow loop play/pause tick
  useEffect(() => {
    if (playerTimerRef.current) {
      clearInterval(playerTimerRef.current);
    }

    if (isPlaying && frames.length > 1) {
      const activeFrame = frames[currentFrameIndex];
      const timerDelay = activeFrame ? activeFrame.duration : globalDelay;
      
      playerTimerRef.current = setInterval(() => {
        setCurrentFrameIndex((prevIndex) => (prevIndex + 1) % frames.length);
      }, timerDelay);
    }

    return () => {
      if (playerTimerRef.current) clearInterval(playerTimerRef.current);
    };
  }, [isPlaying, frames, currentFrameIndex, globalDelay]);

  // Adjust current frame index boundaries if frame length changes
  useEffect(() => {
    if (frames.length === 0) {
      setCurrentFrameIndex(0);
    } else if (currentFrameIndex >= frames.length) {
      setCurrentFrameIndex(frames.length - 1);
    }
  }, [frames.length]);

  const processUploadFiles = (files: FileList) => {
    const loaded: GifFrame[] = [];
    const proms = Array.from(files).map((file) => {
      if (!file.type.startsWith('image/')) return Promise.resolve();
      const id = Math.random().toString(36).substring(2, 9);
      const url = URL.createObjectURL(file);
      
      return new Promise<void>((resolve) => {
        const img = new Image();
        img.onload = () => {
          loaded.push({
            id,
            previewUrl: url,
            duration: globalDelay,
            width: img.width,
            height: img.height,
          });
          resolve();
        };
        img.onerror = () => resolve();
        img.src = url;
      });
    });

    Promise.all(proms).then(() => {
      if (loaded.length > 0) {
        setFrames((prev) => [...prev, ...loaded]);
        // Default sizing based on first uploaded image if we haven't modified it yet
        if (frames.length === 0 && loaded[0]) {
          // Normalize dimension sizes to fit nice margins
          const aspect = loaded[0].width / loaded[0].height;
          if (aspect > 1) {
            setGifWidth(500);
            setGifHeight(Math.round(500 / aspect));
          } else {
            setGifHeight(500);
            setGifWidth(Math.round(500 * aspect));
          }
        }
      }
    });
  };

  const shiftFrame = (index: number, direction: 'left' | 'right') => {
    if (direction === 'left' && index === 0) return;
    if (direction === 'right' && index === frames.length - 1) return;

    const newFrames = [...frames];
    const target = direction === 'left' ? index - 1 : index + 1;
    const temp = newFrames[index];
    newFrames[index] = newFrames[target];
    newFrames[target] = temp;
    setFrames(newFrames);
  };

  const removeFrame = (index: number) => {
    setFrames((prev) => prev.filter((_, i) => i !== index));
  };

  const updateFrameDelay = (index: number, ms: number) => {
    setFrames((prev) =>
      prev.map((frame, i) => (i === index ? { ...frame, duration: ms } : frame))
    );
  };

  const applyGlobalDelay = (ms: number) => {
    setGlobalDelay(ms);
    setFrames((prev) => prev.map((f) => ({ ...f, duration: ms })));
  };

  const compileAndGenerateGif = () => {
    if (frames.length < 2) return;
    setIsCompiling(true);
    setCompilationProgress('Reading frames...');

    // Convert blob urls/canvas to Image nodes or raw data URIs
    const imagesArrayPromises = frames.map((f) => {
      return new Promise<string>((resolve, reject) => {
        const xhr = new XMLHttpRequest();
        xhr.onload = function () {
          const reader = new FileReader();
          reader.onloadend = function () {
            resolve(reader.result as string);
          };
          reader.readAsDataURL(xhr.response);
        };
        xhr.onerror = () => reject(new Error('Failed to read frame blob'));
        xhr.open('GET', f.previewUrl);
        xhr.responseType = 'blob';
        xhr.send();
      });
    });

    Promise.all(imagesArrayPromises)
      .then((base64Images) => {
        setCompilationProgress('Encoding animated vectors...');
        
        // Match gifshot's expected options
        gifshot.createGIF(
          {
            images: base64Images,
            gifWidth: gifWidth,
            gifHeight: gifHeight,
            interval: globalDelay / 1000, // interval in seconds
            numWorkers: 2,
          },
          (obj) => {
            if (obj.error) {
              setCompilationProgress(`Compilation failed: ${obj.errorMsg}`);
              setIsCompiling(false);
            } else {
              setCompiledGifUrl(obj.image);
              setIsCompiling(false);
              setCompilationProgress('');
            }
          }
        );
      })
      .catch((err) => {
        setCompilationProgress('Frame reading failure.');
        setIsCompiling(false);
      });
  };

  const downloadGif = () => {
    if (!compiledGifUrl) return;
    const link = document.createElement('a');
    link.download = `julfy_animated_${Date.now()}.gif`;
    link.href = compiledGifUrl;
    link.click();
  };

  return (
    <div id="gif-creator-tab" className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
      {/* Controls List - Left Side */}
      <div className="lg:col-span-5 space-y-6">
        <div className="bg-white rounded-2xl border border-gray-100 p-6 shadow-xs">
          <h2 className="text-sm font-semibold text-gray-700 uppercase tracking-wider flex items-center gap-1.5 mb-2">
            <Layers className="w-4 h-4 text-indigo-600" />
            1. Compile Settings
          </h2>
          <p className="text-xs text-gray-400 mb-6 font-sans">
            Configure default frame dimensions, delays, and loop properties.
          </p>

          {/* Width Height */}
          <div className="grid grid-cols-2 gap-4 mb-5">
            <div>
              <span className="block text-[10px] uppercase font-semibold text-gray-500 mb-1.5">Width (px)</span>
              <input
                id="gif-width"
                type="number"
                value={gifWidth}
                onChange={(e) => setGifWidth(Math.max(50, Number(e.target.value)))}
                className="w-full px-3 py-2 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 font-mono text-sm"
              />
            </div>
            <div>
              <span className="block text-[10px] uppercase font-semibold text-gray-500 mb-1.5">Height (px)</span>
              <input
                id="gif-height"
                type="number"
                value={gifHeight}
                onChange={(e) => setGifHeight(Math.max(50, Number(e.target.value)))}
                className="w-full px-3 py-2 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 font-mono text-sm"
              />
            </div>
          </div>

          {/* Delay milliseconds slider */}
          <div className="mb-6">
            <div className="flex justify-between items-center mb-1.5 text-[10px] uppercase font-semibold text-gray-500">
              <span>Universal Frame Delay</span>
              <span className="text-indigo-600 font-bold font-mono text-xs">{globalDelay}ms</span>
            </div>
            <input
              id="global-delay-slider"
              type="range"
              min="50"
              max="2000"
              step="50"
              value={globalDelay}
              onChange={(e) => applyGlobalDelay(Number(e.target.value))}
              className="w-full accent-indigo-600 cursor-pointer"
            />
            <div className="flex justify-between text-[9px] text-gray-400 font-mono mt-1">
              <span>Hyper Fast (50ms)</span>
              <span>Default (300ms)</span>
              <span>Lazy Slideshow (2s)</span>
            </div>
          </div>

          {/* Sizing helpers presets */}
          <div className="mb-4">
            <span className="block text-[10px] uppercase font-semibold text-gray-500 mb-2">Sizing Presets</span>
            <div className="flex flex-wrap gap-1">
              {[
                { label: 'Avatar (200x200)', w: 200, h: 200 },
                { label: 'Medium Square (400x400)', w: 400, h: 400 },
                { label: 'Banner HD (600x300)', w: 600, h: 300 },
                { label: 'Figma Auto (480x480)', w: 480, h: 480 },
              ].map((pres, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => {
                    setGifWidth(pres.w);
                    setGifHeight(pres.h);
                  }}
                  className="text-[9px] px-2 py-1 font-semibold border border-gray-200 rounded hover:border-indigo-600 transition-colors bg-white text-gray-500 hover:text-indigo-600"
                >
                  {pres.label}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Frames ordering list */}
        <div className="bg-white rounded-2xl border border-gray-100 p-6 shadow-xs">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-sm font-semibold text-gray-700">Frame Sequence Queue ({frames.length})</h3>
            <button
              id="gif-upload-trigger"
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="text-xs bg-indigo-50 hover:bg-indigo-100/60 font-semibold text-indigo-700 px-2.5 py-1.5 border border-indigo-100 rounded-lg flex items-center gap-1.5 transition-colors"
            >
              <Upload className="w-3.5 h-3.5" />
              Add Frame
            </button>
          </div>

          <div className="space-y-2 max-h-[320px] overflow-y-auto pr-1">
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              multiple
              onChange={(e) => e.target.files && processUploadFiles(e.target.files)}
              className="hidden"
            />

            {frames.length === 0 ? (
              <div className="text-center py-8 border border-dashed border-gray-100 rounded-xl">
                <p className="text-xs text-gray-400">Import frames to arrange order.</p>
              </div>
            ) : (
              frames.map((frame, index) => (
                <div
                  key={frame.id}
                  className={`flex items-center justify-between p-2 rounded-xl border border-gray-100 bg-white transition-all ${
                    currentFrameIndex === index ? 'ring-2 ring-indigo-500 border-indigo-600 bg-indigo-50/10' : ''
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <span className="text-[10px] font-bold font-mono text-slate-400 px-1 bg-slate-100 rounded">
                      #{index + 1}
                    </span>
                    <img
                      src={frame.previewUrl}
                      alt=""
                      referrerPolicy="no-referrer"
                      className="w-10 h-10 object-cover rounded-lg border border-gray-100 flex-shrink-0"
                    />
                    <div className="min-w-0">
                      <span className="block text-[9px] text-gray-400 uppercase font-mono tracking-wider">Frame Delay</span>
                      <input
                        type="number"
                        value={frame.duration}
                        onChange={(e) => updateFrameDelay(index, Math.max(20, Number(e.target.value)))}
                        className="w-16 px-1 py-0.5 bg-slate-50 border border-gray-100 focus:outline-hidden focus:ring-1 focus:ring-indigo-500 rounded text-xs font-semibold font-mono"
                      />
                      <span className="text-[9px] text-gray-400 font-semibold ml-1">ms</span>
                    </div>
                  </div>

                  {/* Ordering Arrows */}
                  <div className="flex items-center gap-1.5">
                    <button
                      id={`btn-shift-left-${index}`}
                      type="button"
                      disabled={index === 0}
                      onClick={() => shiftFrame(index, 'left')}
                      className="p-1 rounded-md text-slate-400 bg-slate-50 border border-slate-100 hover:text-indigo-600 disabled:opacity-30 disabled:hover:text-slate-400"
                    >
                      <ArrowLeft className="w-3.5 h-3.5" />
                    </button>
                    <button
                      id={`btn-shift-right-${index}`}
                      type="button"
                      disabled={index === frames.length - 1}
                      onClick={() => shiftFrame(index, 'right')}
                      className="p-1 rounded-md text-slate-400 bg-slate-50 border border-slate-100 hover:text-indigo-600 disabled:opacity-30 disabled:hover:text-slate-400"
                    >
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                    <button
                      id={`btn-del-frame-${index}`}
                      type="button"
                      onClick={() => removeFrame(index)}
                      className="p-1 rounded-md text-slate-400 bg-red-50 border border-red-100/50 hover:text-red-600"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Screen workspace / Export - Right Side */}
      <div className="lg:col-span-7 space-y-6">
        {/* Dynamic motion player view */}
        <div className="bg-white rounded-2xl border border-gray-100 p-5 shadow-xs">
          <div className="flex justify-between items-center mb-3">
            <span className="text-xs font-semibold text-gray-700 flex items-center gap-1.5">
              <Video className="w-4 h-4 text-indigo-500" />
              Live Loop Simulator Preview
            </span>
            <div className="flex items-center gap-2">
              <button
                id="btn-play-pause-toggle"
                type="button"
                onClick={() => setIsPlaying(!isPlaying)}
                className="p-1 border border-gray-100 bg-slate-50 hover:bg-slate-200 rounded-lg text-slate-700 hover:text-indigo-600 cursor-pointer transition-colors flex items-center justify-center"
              >
                {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
              </button>
              <span className="text-[10px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded font-mono">
                {frames.length > 0 ? `Frame ${currentFrameIndex + 1} of ${frames.length}` : '0 Frames'}
              </span>
            </div>
          </div>

          <div className="relative h-[400px] w-full bg-slate-50 border border-slate-100 rounded-xl flex items-center justify-center overflow-hidden">
            {frames.length > 0 ? (
              <div className="relative max-h-[380px] max-w-[95%] flex flex-col justify-center items-center">
                <img
                  src={frames[currentFrameIndex]?.previewUrl}
                  alt={`Frame ${currentFrameIndex + 1}`}
                  referrerPolicy="no-referrer"
                  className="max-h-[360px] max-w-full object-contain shadow-xs border border-gray-100/40 rounded-lg"
                />
                
                {/* Visual frame dots indicator footer on top of image */}
                <div className="absolute bottom-4 flex gap-1 bg-black/60 backdrop-blur-3xs px-2.5 py-1 rounded-full cursor-default select-none">
                  {frames.map((_, i) => (
                    <div
                      key={i}
                      onClick={() => setCurrentFrameIndex(i)}
                      className={`w-1.5 h-1.5 rounded-full cursor-pointer transition-all ${
                        currentFrameIndex === i ? 'bg-white scale-125' : 'bg-white/40 hover:bg-white/70'
                      }`}
                    />
                  ))}
                </div>
              </div>
            ) : (
              /* Inside frame empty state */
              <div className="text-center">
                <Upload className="w-12 h-12 text-slate-300 mx-auto animate-bounce mb-3" />
                <h4 className="text-xs font-semibold text-slate-600 mb-1">Live frame preview</h4>
                <p className="text-[11px] text-gray-400 max-w-xs">
                  Upload multiple photos in the sequence manager drawer to generate instant flipbook loop frames!
                </p>
              </div>
            )}
          </div>

          {/* Compiler button */}
          <div className="mt-4 flex flex-col gap-3">
            <div className="flex items-center justify-between">
              <span className="text-[10px] text-gray-400 font-mono">
                *Uses inline hardware-accelerated loops.
              </span>
              <button
                id="btn-trigger-gif-compiler"
                type="button"
                disabled={frames.length < 2 || isCompiling}
                onClick={compileAndGenerateGif}
                className="inline-flex items-center gap-1.5 px-5 py-2.5 bg-indigo-600 disabled:bg-indigo-300 hover:bg-indigo-700 text-white font-bold rounded-xl text-xs shadow-md transition-all cursor-pointer"
              >
                {isCompiling ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    Compiling GIF...
                  </>
                ) : (
                  <>
                    <RefreshCw className="w-3.5 h-3.5" />
                    Compile Animated GIF
                  </>
                )}
              </button>
            </div>
            {compilationProgress && (
              <span className="text-[10px] bg-slate-50 text-indigo-600 border border-slate-100 py-1.5 px-3 rounded-lg font-mono font-semibold animate-pulse text-center">
                ⚙️ {compilationProgress}
              </span>
            )}
          </div>
        </div>

        {/* Compile Outputs display block */}
        {compiledGifUrl && (
          <div className="bg-emerald-50/20 border border-emerald-100 rounded-2xl p-6 shadow-xs animate-slideUp">
            <div className="flex gap-4 items-start">
              <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-100 text-emerald-600 flex-shrink-0">
                <CheckCircle className="w-6 h-6" />
              </div>
              <div className="flex-grow space-y-4">
                <div>
                  <h4 className="text-sm font-bold text-slate-800 flex items-center gap-2">
                    Animation Compiled Successfully!
                  </h4>
                  <p className="text-xs text-gray-500 mt-1">
                    Your generated `.gif` loop bundle is ready to be exported.
                  </p>
                </div>

                {/* Actual rendering of output */}
                <div className="border border-slate-200/50 bg-white rounded-xl p-3 flex justify-center items-center h-[260px] overflow-hidden">
                  <img
                    id="gif-compilation-result-preview"
                    src={compiledGifUrl}
                    alt="Compiled loop result"
                    referrerPolicy="no-referrer"
                    className="max-h-[240px] max-w-full object-contain"
                  />
                </div>

                {/* Sizing description */}
                <div className="flex items-center justify-between text-xs text-emerald-800">
                  <span className="font-mono font-medium">Export layout: {gifWidth} &times; {gifHeight} px</span>
                  <button
                    id="btn-trigger-compiled-gif-download"
                    type="button"
                    onClick={downloadGif}
                    className="inline-flex items-center gap-1.5 font-bold text-[11px] px-3.5 py-2 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 transition-colors shadow-sm cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" />
                    Download Animated GIF
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
