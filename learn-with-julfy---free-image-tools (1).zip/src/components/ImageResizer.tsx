/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { Maximize2, Crop, Download, Upload, Sliders, Settings, Ratio, RefreshCw } from 'lucide-react';
import { ImageFile } from '../types';

export default function ImageResizer() {
  const [images, setImages] = useState<ImageFile[]>([]);
  const [selectedImageId, setSelectedImageId] = useState<string | null>(null);
  
  // Resize State
  const [widthInput, setWidthInput] = useState<string>('');
  const [heightInput, setHeightInput] = useState<string>('');
  const [lockAspectRatio, setLockAspectRatio] = useState<boolean>(true);
  const [aspectRatioValue, setAspectRatioValue] = useState<number>(1);
  const [scalePercentage, setScalePercentage] = useState<number>(100);

  // Crop State
  const [cropActive, setCropActive] = useState<boolean>(false);
  const [cropPreset, setCropPreset] = useState<string>('free'); // free, 1:1, 4:5, 16:9, 9:16
  const [cropX, setCropX] = useState<number>(0); // 0-100 percentage of width
  const [cropY, setCropY] = useState<number>(0); // 0-100 percentage of height
  const [cropW, setCropW] = useState<number>(100); // percentage
  const [cropH, setCropH] = useState<number>(100); // percentage

  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [resizedDimensions, setResizedDimensions] = useState<{w: number, h: number}>({w: 0, h:0});
  const fileInputRef = useRef<HTMLInputElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const selectedImage = images.find((img) => img.id === selectedImageId);

  // When selected image changes, set input fields
  useEffect(() => {
    if (selectedImage) {
      setWidthInput(selectedImage.width.toString());
      setHeightInput(selectedImage.height.toString());
      setAspectRatioValue(selectedImage.width / selectedImage.height);
      setResizedDimensions({ w: selectedImage.width, h: selectedImage.height });
      // Reset crop params
      setCropX(0);
      setCropY(0);
      setCropW(100);
      setCropH(100);
      setCropPreset('free');
      setCropActive(false);
      setScalePercentage(100);
    }
  }, [selectedImageId]);

  // Handle aspect ratios on crop select
  useEffect(() => {
    if (!selectedImage) return;
    if (cropPreset === 'free') return;

    let targetRatio = 1;
    if (cropPreset === '1:1') targetRatio = 1;
    if (cropPreset === '4:5') targetRatio = 4/5;
    if (cropPreset === '16:9') targetRatio = 16/9;
    if (cropPreset === '9:16') targetRatio = 9/16;

    // Calculate crop dimensions matching the aspect ratio, centered
    const imgRatio = selectedImage.width / selectedImage.height;

    let targetW = 100;
    let targetH = 100;

    if (targetRatio > imgRatio) {
      // Crop is wider than image (crop height must shrink)
      targetH = (100 / targetRatio) * imgRatio;
      targetW = 100;
    } else {
      // Crop is taller than image (crop width must shrink)
      targetW = (100 * targetRatio) / imgRatio;
      targetH = 100;
    }

    setCropW(Math.round(targetW));
    setCropH(Math.round(targetH));
    setCropX(Math.round((100 - targetW) / 2));
    setCropY(Math.round((100 - targetH) / 2));
  }, [cropPreset, selectedImageId]);

  // Update real-time canvas preview
  useEffect(() => {
    if (!selectedImage) return;
    drawCanvas();
  }, [selectedImage, widthInput, heightInput, cropActive, cropX, cropY, cropW, cropH]);

  const drawCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas || !selectedImage) return;

    const img = new Image();
    img.onload = () => {
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      const destW = parseInt(widthInput) || selectedImage.width;
      const destH = parseInt(heightInput) || selectedImage.height;

      canvas.width = destW;
      canvas.height = destH;

      ctx.clearRect(0, 0, destW, destH);

      // Sources
      let srcX = 0;
      let srcY = 0;
      let srcW = img.width;
      let srcH = img.height;

      if (cropActive) {
        srcX = (cropX / 100) * img.width;
        srcY = (cropY / 100) * img.height;
        srcW = (cropW / 100) * img.width;
        srcH = (cropH / 100) * img.height;
      }

      ctx.drawImage(
        img,
        srcX, srcY, srcW, srcH, // crop source
        0, 0, destW, destH // resize target
      );

      setPreviewUrl(canvas.toDataURL('image/png'));
      setResizedDimensions({ w: destW, h: destH });
    };
    img.src = selectedImage.previewUrl;
  };

  const handleWidthChange = (val: string) => {
    setWidthInput(val);
    const numeric = parseInt(val);
    if (numeric && lockAspectRatio && selectedImage) {
      const resultHeight = Math.round(numeric / aspectRatioValue);
      setHeightInput(resultHeight.toString());
    }
  };

  const handleHeightChange = (val: string) => {
    setHeightInput(val);
    const numeric = parseInt(val);
    if (numeric && lockAspectRatio && selectedImage) {
      const resultWidth = Math.round(numeric * aspectRatioValue);
      setWidthInput(resultWidth.toString());
    }
  };

  const applyPercentScaling = (pct: number) => {
    if (!selectedImage) return;
    setScalePercentage(pct);
    const targetW = Math.round((selectedImage.width * pct) / 100);
    const targetH = Math.round((selectedImage.height * pct) / 100);
    setWidthInput(targetW.toString());
    setHeightInput(targetH.toString());
  };

  const handleDownload = () => {
    const canvas = canvasRef.current;
    if (!canvas || !selectedImage) return;

    const link = document.createElement('a');
    const originalNameNoExt = selectedImage.name.substring(0, selectedImage.name.lastIndexOf('.')) || selectedImage.name;
    link.download = `${originalNameNoExt}_resized.png`;
    link.href = canvas.toDataURL('image/png');
    link.click();
  };

  const processFiles = (files: FileList) => {
    const loaded: ImageFile[] = [];
    const proms = Array.from(files).map((file) => {
      if (!file.type.startsWith('image/')) return Promise.resolve();
      const id = Math.random().toString(36).substring(2, 9);
      const url = URL.createObjectURL(file);
      return new Promise<void>((resolve) => {
        const img = new Image();
        img.onload = () => {
          loaded.push({
            id,
            name: file.name,
            file,
            previewUrl: url,
            originalSize: file.size,
            width: img.width,
            height: img.height,
          });
          resolve();
        };
        img.onerror = () => resolve();
        img.src = url;
      });
    });

    Promise.all(proms).then(() => {
      if (loaded.length > 0) {
        setImages((prev) => [...prev, ...loaded]);
        setSelectedImageId(loaded[0].id);
      }
    });
  };

  return (
    <div id="image-resizer-tab" className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
      {/* Settings Grid - Left Column */}
      <div className="lg:col-span-5 space-y-6">
        <div className="bg-white rounded-2xl border border-gray-100 p-6 shadow-xs">
          <h2 className="text-lg font-semibold text-gray-900 mb-2 flex items-center gap-2">
            <Maximize2 className="w-5 h-5 text-indigo-600" />
            1. Scale & Crop Configurations
          </h2>
          <p className="text-sm text-gray-500 mb-6 font-sans">
            Resize by exact pixels, scaled percentages, or snap-crop areas.
          </p>

          {/* Width & Height Input Row */}
          <div className="grid grid-cols-2 gap-4 mb-4">
            <div>
              <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1.5">
                Width (pixels)
              </label>
              <input
                id="input-resize-width"
                type="number"
                disabled={!selectedImage}
                value={widthInput}
                onChange={(e) => handleWidthChange(e.target.value)}
                placeholder="Width"
                className="w-full px-3 py-2 border border-gray-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-indigo-500 font-mono text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1.5">
                Height (pixels)
              </label>
              <input
                id="input-resize-height"
                type="number"
                disabled={!selectedImage}
                value={heightInput}
                onChange={(e) => handleHeightChange(e.target.value)}
                placeholder="Height"
                className="w-full px-3 py-2 border border-gray-200 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-indigo-500 font-mono text-sm"
              />
            </div>
          </div>

          {/* Aspect ratio lock checkbox */}
          <div className="mb-6 flex items-center gap-2">
            <input
              id="lock-aspect-ratio"
              type="checkbox"
              disabled={!selectedImage}
              checked={lockAspectRatio}
              onChange={(e) => setLockAspectRatio(e.target.checked)}
              className="w-4 h-4 text-indigo-600 border-gray-300 rounded-sm focus:ring-indigo-500 cursor-pointer"
            />
            <label htmlFor="lock-aspect-ratio" className="text-xs font-medium text-gray-700 cursor-pointer select-none">
              Lock original aspect ratio ({aspectRatioValue.toFixed(2)})
            </label>
          </div>

          {/* Preset Percentage Scalers */}
          <div className="mb-6">
            <label className="block text-xs font-semibold text-gray-700 uppercase tracking-wider mb-2">
              Quick Scale Factor
            </label>
            <div className="flex flex-wrap gap-1.5">
              {[25, 50, 75, 100, 150, 200].map((pct) => (
                <button
                  key={pct}
                  type="button"
                  disabled={!selectedImage}
                  onClick={() => applyPercentScaling(pct)}
                  className={`px-2.5 py-1.5 text-xs font-semibold font-mono rounded-lg border transition-all ${
                    scalePercentage === pct && selectedImage
                      ? 'bg-indigo-600 border-indigo-600 text-white shadow-3xs'
                      : 'bg-white border-gray-200 text-gray-600 hover:border-gray-300 hover:bg-gray-50 disabled:opacity-50'
                  }`}
                >
                  {pct}%
                </button>
              ))}
            </div>
          </div>

          <hr className="border-gray-100 my-6" />

          {/* Interactive Crop Sub-module */}
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <label className="text-xs font-semibold text-gray-700 uppercase tracking-wider flex items-center gap-1.5">
                <Crop className="w-4 h-4 text-indigo-600" />
                Regional Cropping
              </label>
              <div className="flex items-center gap-2">
                <span className="text-[10px] text-gray-400">Enable crop overlay</span>
                <input
                  id="crop-overlay-toggle"
                  type="checkbox"
                  disabled={!selectedImage}
                  checked={cropActive}
                  onChange={(e) => setCropActive(e.target.checked)}
                  className="w-4 h-4 text-indigo-600 border-gray-300 rounded-sm focus:ring-indigo-500 cursor-pointer"
                />
              </div>
            </div>

            {cropActive && selectedImage && (
              <div className="space-y-4 animate-fadeIn">
                {/* Crop presets ratios */}
                <div>
                  <span className="block text-[11px] text-gray-400 mb-1.5">Preset Crop Ratio</span>
                  <div className="grid grid-cols-5 gap-1">
                    {[
                      { id: 'free', label: 'Free' },
                      { id: '1:1', label: 'Square' },
                      { id: '4:5', label: 'Portrait' },
                      { id: '16:9', label: 'Widescreen' },
                      { id: '9:16', label: 'Story' },
                    ].map((p) => (
                      <button
                        key={p.id}
                        type="button"
                        onClick={() => setCropPreset(p.id)}
                        className={`text-[10px] py-1 px-1.5 font-semibold border rounded ${
                          cropPreset === p.id
                            ? 'bg-indigo-50 border-indigo-600 text-indigo-600 font-bold'
                            : 'bg-white border-gray-200 text-gray-500 hover:border-gray-300'
                        }`}
                      >
                        {p.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Coordinate adjustment sliders (X, Y, W, H) */}
                <div className="space-y-3 bg-slate-50 rounded-xl p-3 border border-slate-100 font-mono text-[10px]">
                  <div>
                    <div className="flex justify-between mb-1 text-gray-600">
                      <span>Crop Start X (Horizontal offset)</span>
                      <span>{cropX}%</span>
                    </div>
                    <input
                      type="range"
                      min="0"
                      max={100 - cropW}
                      value={cropX}
                      onChange={(e) => setCropX(Number(e.target.value))}
                      className="w-full accent-indigo-600"
                    />
                  </div>
                  <div>
                    <div className="flex justify-between mb-1 text-gray-600">
                      <span>Crop Start Y (Vertical offset)</span>
                      <span>{cropY}%</span>
                    </div>
                    <input
                      type="range"
                      min="0"
                      max={100 - cropH}
                      value={cropY}
                      onChange={(e) => setCropY(Number(e.target.value))}
                      className="w-full accent-indigo-600"
                    />
                  </div>
                  <div>
                    <div className="flex justify-between mb-1 text-gray-600">
                      <span>Crop Frame Width</span>
                      <span>{cropW}%</span>
                    </div>
                    <input
                      type="range"
                      min="10"
                      max={100 - cropX}
                      disabled={cropPreset !== 'free'}
                      value={cropW}
                      onChange={(e) => setCropW(Number(e.target.value))}
                      className="w-full accent-indigo-600 disabled:opacity-40"
                    />
                  </div>
                  <div>
                    <div className="flex justify-between mb-1 text-gray-600">
                      <span>Crop Frame Height</span>
                      <span>{cropH}%</span>
                    </div>
                    <input
                      type="range"
                      min="10"
                      max={100 - cropY}
                      disabled={cropPreset !== 'free'}
                      value={cropH}
                      onChange={(e) => setCropH(Number(e.target.value))}
                      className="w-full accent-indigo-600 disabled:opacity-40"
                    />
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Upload Drawer / File Queuer */}
        <div className="bg-white rounded-2xl border border-gray-100 p-6 shadow-xs">
          <div className="flex justify-between items-center mb-3">
            <h3 className="text-sm font-semibold text-gray-800">Available Files ({images.length})</h3>
          </div>
          
          <div
            onClick={() => fileInputRef.current?.click()}
            className="border-2 border-dashed border-gray-200 hover:border-gray-300 rounded-xl p-4 text-center cursor-pointer hover:bg-gray-50/40 transition-colors"
          >
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              multiple
              onChange={(e) => e.target.files && processFiles(e.target.files)}
              className="hidden"
            />
            <p className="text-xs font-semibold text-gray-700">Add or drag resizing images here</p>
          </div>

          {images.length > 0 && (
            <div className="mt-4 flex gap-1.5 overflow-x-auto pb-2 scrollbar-none">
              {images.map((img) => (
                <button
                  key={img.id}
                  type="button"
                  onClick={() => setSelectedImageId(img.id)}
                  className={`relative flex-shrink-0 w-12 h-12 rounded-lg overflow-hidden border-2 transition-all ${
                    selectedImageId === img.id ? 'border-indigo-600 scale-95 shadow-sm' : 'border-gray-100 opacity-75 hover:opacity-100'
                  }`}
                >
                  <img src={img.previewUrl} alt="" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Editor & Download Section - Right Column */}
      <div className="lg:col-span-7 space-y-6">
        {selectedImage ? (
          <>
            {/* Visual Canvas Display frame */}
            <div className="bg-white rounded-2xl border border-gray-100 p-5 shadow-xs">
              <div className="flex justify-between items-center mb-3">
                <span className="text-xs font-semibold text-gray-700 flex items-center gap-1.5">
                  <Settings className="w-4 h-4 text-indigo-500" />
                  Interactive Crop & Scale Workspace
                </span>
                <span className="text-[10px] bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded-md font-mono">
                  {resizedDimensions.w} &times; {resizedDimensions.h} Output
                </span>
              </div>

              {/* Working stage wrapper */}
              <div className="relative h-[380px] w-full bg-slate-50 border border-slate-100 rounded-xl flex items-center justify-center overflow-hidden">
                {/* Standard canvas hidden */}
                <canvas ref={canvasRef} className="hidden" />

                {/* If cropping, overlay cropping visual representation on top of original */}
                {cropActive ? (
                  <div className="absolute inset-0 flex items-center justify-center p-4">
                    <div className="relative max-h-full max-w-full flex items-center justify-center">
                      <img
                        id="original-crop-source-preview"
                        src={selectedImage.previewUrl}
                        alt="Original"
                        referrerPolicy="no-referrer"
                        className="max-h-[340px] max-w-full object-contain opacity-50 select-none pointer-events-none"
                      />
                      {/* Transparent Overlay representing cropped sector */}
                      <div
                        className="absolute border-2 border-indigo-600 bg-black/10 shadow-[0_0_0_9999px_rgba(0,0,0,0.6)] rounded-sm"
                        style={{
                          left: `${cropX}%`,
                          top: `${cropY}%`,
                          width: `${cropW}%`,
                          height: `${cropH}%`,
                        }}
                      >
                        {/* Center coordinate point */}
                        <div className="absolute inset-x-0 top-1/2 -translate-y-1/2 flex justify-between px-2 text-[10px] text-white font-mono pointer-events-none">
                          <span className="bg-slate-900/80 px-1 rounded">X: {cropX}%</span>
                          <span className="bg-slate-900/80 px-1 rounded">W: {cropW}%</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ) : (
                  /* Standard Output preview */
                  previewUrl && (
                    <img
                      src={previewUrl}
                      alt="Resized / Cropped output"
                      referrerPolicy="no-referrer"
                      className="max-h-[340px] max-w-[95%] object-contain"
                    />
                  )
                )}
              </div>

              <div className="mt-4 flex items-center justify-between">
                <div className="text-[10px] font-mono text-gray-400">
                  {cropActive ? '⚠️ Crop Mask Active. Output fits the target size.' : 'Original Pixels preserved.'}
                </div>
                <button
                  id="btn-trigger-resized-download"
                  type="button"
                  onClick={handleDownload}
                  className="inline-flex items-center gap-1.5 px-4 py-2.5 bg-indigo-600 text-white rounded-xl text-xs font-semibold shadow-md hover:bg-indigo-700 transition-all"
                >
                  <Download className="w-3.5 h-3.5" />
                  Apply & Download Image
                </button>
              </div>
            </div>

            {/* Scale guide metadata */}
            <div className="bg-white rounded-xl border border-gray-100 p-4 shadow-3xs flex gap-3 items-center">
              <div className="p-2 rounded-lg bg-emerald-50 text-emerald-600">
                <Ratio className="w-5 h-5" />
              </div>
              <div className="text-xs">
                <p className="font-semibold text-gray-800">Proportion Tip</p>
                <p className="text-gray-500 mt-0.5 leading-relaxed">
                  Keeping the Aspect Ratio locked maintains visual proportions automatically. Turn off "Lock aspect ratio" if you want custom squeeze/stretch width/height transformations.
                </p>
              </div>
            </div>
          </>
        ) : (
          /* Empty View state */
          <div className="bg-slate-50 border border-dashed border-gray-200 rounded-3xl p-12 text-center h-[480px] flex flex-col justify-center items-center">
            <Maximize2 className="w-12 h-12 text-gray-300 mb-3" />
            <h3 className="text-base font-bold text-gray-800 mb-1">No Image Imported</h3>
            <p className="text-xs text-gray-500 max-w-xs mb-4">
              Add photos or design sheets to scale standard boundaries or crop rectangular frames instantly!
            </p>
            <button
              id="empty-resizer-btn"
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold rounded-xl shadow-xs"
            >
              Select Image to Resize
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
