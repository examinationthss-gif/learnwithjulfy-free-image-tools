declare module 'gifshot';
